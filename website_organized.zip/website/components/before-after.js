/* ─────────────────────────────────────────────────────────
   BEFORE / AFTER SECTION COMPONENT
   Usage: call renderBeforeAfter(productId) to generate
   the before/after comparison HTML for a product page.
──────────────────────────────────────────────────────── */

/* Currently before/after sections are rendered inline in
   renderProduct() inside scripts/main.js */
