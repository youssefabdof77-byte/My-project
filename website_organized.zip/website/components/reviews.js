/* =============================================================
   PUREFORM — components/reviews.js
   Review UI functions: starHtml(), renderReviewsSection(),
   showMoreRevs(), pickStar(), submitReview()

   DEPENDS ON: REVIEWS constant (defined in components/reviews-data.js
               or inline in scripts/main.js data section)
   ============================================================= */

function starHtml(s,size){
  size=size||'.78rem';
  var filled='★'.repeat(s);
  var empty='☆'.repeat(5-s);
  return '<span style="color:var(--gold);font-size:'+size+';letter-spacing:1px">'+filled+'<span style="opacity:.3">'+empty+'</span></span>';
}

function renderReviewsSection(pid, revs, avg){
  var l = document.documentElement.lang||'ar';
  var T = {
    ar:{title:'آراء العملاء',verified:'مشتري موثق',helpful:'مفيد؟',yes:'👍 نعم',
        showMore:'عرض المزيد من التقييمات',writeTitle:'شاركنا رأيك ✍️',
        writeSub:'تجربتك تساعد عملاء آخرين في اتخاذ قرارهم',
        namePh:'اسمك (مثال: أحمد محمد)…',reviewPh:'اكتب تجربتك مع المنتج…',
        submitBtn:'إرسال التقييم عبر واتساب',starLabels:['','ضعيف','مقبول','جيد','ممتاز','رائع!'],
        errName:'أدخل اسمك',errStar:'اختر عدد النجوم',errText:'اكتب رأيك',
        waMsg:function(name,stars,text,prod){
          return 'تقييم جديد لـ '+prod+':\n\n'
                +'👤 الاسم: '+name+'\n'
                +'⭐ التقييم: '+stars+'/5\n'
                +'💬 الرأي: '+text;
        }
    },
    en:{title:'Customer Reviews',verified:'Verified buyer',helpful:'Helpful?',yes:'👍 Yes',
        showMore:'Show more reviews',writeTitle:'Write a Review ✍️',
        writeSub:'Your experience helps others make better decisions',
        namePh:'Your name (e.g. Ahmed M.)…',reviewPh:'Write your experience with this product…',
        submitBtn:'Submit Review via WhatsApp',starLabels:['','Poor','Fair','Good','Great','Excellent!'],
        errName:'Enter your name',errStar:'Choose a star rating',errText:'Write your review',
        waMsg:function(name,stars,text,prod){
          return 'New review for '+prod+':\n\n'
                +'👤 Name: '+name+'\n'
                +'⭐ Rating: '+stars+'/5\n'
                +'💬 Review: '+text;
        }
    },
    fr:{title:'Avis clients',verified:'Acheteur vérifié',helpful:'Utile ?',yes:'👍 Oui',
        showMore:'Voir plus d\'avis',writeTitle:'Donnez votre avis ✍️',
        writeSub:'Votre expérience aide les autres clients',
        namePh:'Votre nom…',reviewPh:'Décrivez votre expérience avec ce produit…',
        submitBtn:'Envoyer l\'avis via WhatsApp',starLabels:['','Mauvais','Passable','Bien','Super','Excellent!'],
        errName:'Entrez votre nom',errStar:'Choisissez une note',errText:'Écrivez votre avis',
        waMsg:function(name,stars,text,prod){
          return 'Nouvel avis pour '+prod+':\n\n'
                +'👤 Nom: '+name+'\n'
                +'⭐ Note: '+stars+'/5\n'
                +'💬 Avis: '+text;
        }
    }
  };
  var t = T[l]||T.ar;

  /* ── Star distribution ── */
  var dist=[0,0,0,0,0,0]; // index 1-5
  revs.forEach(function(r){if(r.s>=1&&r.s<=5)dist[r.s]++;});
  var barRows='';
  for(var s=5;s>=1;s--){
    var pct=revs.length?Math.round(dist[s]/revs.length*100):0;
    barRows+='<div class="rv-bar-row">'
      +'<span class="rv-bar-lbl">'+s+' ★</span>'
      +'<div class="rv-bar-track"><div class="rv-bar-fill" style="width:'+pct+'%"></div></div>'
      +'<span class="rv-bar-pct">'+pct+'%</span>'
      +'</div>';
  }

  /* ── Summary ── */
  var summary='<div class="rv-summary">'
    +'<div class="rv-big">'
    +  '<div class="rv-big-num">'+parseFloat(avg).toFixed(1)+'</div>'
    +  '<div class="rv-big-stars">'+('★'.repeat(Math.round(parseFloat(avg))))+'</div>'
    +  '<div class="rv-big-count">'+revs.length+' '+(l==='ar'?'تقييم':l==='fr'?'avis':'reviews')+'</div>'
    +'</div>'
    +'<div class="rv-bars">'+barRows+'</div>'
    +'</div>';

  /* ── Review cards ── */
  var SHOW_INIT=4;
  var cards=revs.map(function(r,i){
    var initials=r.n?r.n.trim().split(' ').map(function(w){return w[0]||'';}).slice(0,2).join('').toUpperCase():'?';
    return '<div class="rev2 rv" style="'+(i>=SHOW_INIT?'display:none':'')+'" data-rev-idx="'+i+'">'
      +'<div class="rev2-top">'
      +  '<div class="rev2-avatar">'+initials+'</div>'
      +  '<div class="rev2-meta">'
      +    '<div class="rev2-name">'+r.n+'</div>'
      +    '<div class="rev2-stars">'+('★'.repeat(r.s))+'<span style="opacity:.25">'+('★'.repeat(5-r.s))+'</span></div>'
      +    '<div class="rev2-date">'+(r.d||'')+'</div>'
      +  '</div>'
      +  '<div class="rev2-badge"><i class="fas fa-check-circle"></i> '+t.verified+'</div>'
      +'</div>'
      +'<div class="rev2-txt">'+r.t+'</div>'
      +'<div class="rev2-helpful">'
      +  '<span class="rv2-helpful-lbl">'+t.helpful+'</span>'
      +  '<button class="rev2-helpful-btn" onclick="this.classList.toggle(\'liked\')" >'
      +    t.yes
      +  '</button>'
      +'</div>'
      +'</div>';
  }).join('');

  var moreBtn=revs.length>SHOW_INIT
    ?'<button class="revs-more-btn" id="rvmore-'+pid+'" onclick="showMoreRevs(\''+pid+'\')"><i class="fas fa-chevron-down" style="margin-inline-end:.4rem;font-size:.7rem"></i>'+t.showMore+' (+'+(revs.length-SHOW_INIT)+')</button>'
    :'';

  /* ── Write a review form ── */
  var form='<div class="rv-form-section" id="rv-form-'+pid+'">'
    +'<div class="rv-form-title">'+t.writeTitle+'</div>'
    +'<div class="rv-form-sub">'+t.writeSub+'</div>'
    +'<div class="rv-star-picker" id="rv-stars-'+pid+'" data-val="0">'
    +  [1,2,3,4,5].map(function(n){
         return '<span class="rv-star-pick" data-n="'+n+'" onclick="pickStar(\''+pid+'\','+n+')">★</span>';
       }).join('')
    +'</div>'
    +'<input class="rv-field" id="rv-name-'+pid+'" type="text" placeholder="'+t.namePh+'" maxlength="60">'
    +'<textarea class="rv-field" id="rv-txt-'+pid+'" rows="3" placeholder="'+t.reviewPh+'" maxlength="500"></textarea>'
    +'<button class="rv-submit" onclick="submitReview(\''+pid+'\')">'
    +  '<i class="fab fa-whatsapp"></i> '+t.submitBtn
    +'</button>'
    +'</div>';

  return '<div class="revs-section">'
    +'<div class="revs-header">'
    +  '<div class="revs-title">'+t.title+'</div>'
    +'</div>'
    +summary
    +cards
    +moreBtn
    +form
    +'</div>';
}

/* ── Show more reviews ── */
window.showMoreRevs=function(pid){
  var btn=document.getElementById('rvmore-'+pid);
  var hidden=document.querySelectorAll('[data-rev-idx]');
  hidden.forEach(function(el){el.style.display='';});
  if(btn)btn.style.display='none';
};

/* ── Star picker ── */
window.pickStar=function(pid,n){
  var picker=document.getElementById('rv-stars-'+pid);
  if(!picker)return;
  picker.dataset.val=n;
  picker.querySelectorAll('.rv-star-pick').forEach(function(el){
    var v=parseInt(el.dataset.n);
    el.classList.toggle('on',v<=n);
  });
};

/* ── Submit review → WhatsApp ── */
window.submitReview=function(pid){
  var l=document.documentElement.lang||'ar';
  var T={
    ar:{errName:'أدخل اسمك',errStar:'اختر عدد النجوم',errText:'اكتب رأيك',
        waMsg:function(name,stars,text,prod){return 'تقييم جديد لـ '+prod+':\n\n👤 الاسم: '+name+'\n⭐ التقييم: '+stars+'/5\n💬 الرأي: '+text;}},
    en:{errName:'Enter your name',errStar:'Choose a star rating',errText:'Write your review',
        waMsg:function(name,stars,text,prod){return 'New review for '+prod+':\n\n👤 Name: '+name+'\n⭐ Rating: '+stars+'/5\n💬 Review: '+text;}},
    fr:{errName:'Entrez votre nom',errStar:'Choisissez une note',errText:'Écrivez votre avis',
        waMsg:function(name,stars,text,prod){return 'Nouvel avis pour '+prod+':\n\n👤 Nom: '+name+'\n⭐ Note: '+stars+'/5\n💬 Avis: '+text;}}
  };
  var t=T[l]||T.ar;

  var nameEl=document.getElementById('rv-name-'+pid);
  var txtEl=document.getElementById('rv-txt-'+pid);
  var pickerEl=document.getElementById('rv-stars-'+pid);
  if(!nameEl||!txtEl||!pickerEl)return;

  var name=nameEl.value.trim();
  var text=txtEl.value.trim();
  var stars=parseInt(pickerEl.dataset.val||0);
  var prod=window.PRODUCTS&&window.PRODUCTS[pid]?window.PRODUCTS[pid].nm:pid;

  var ok=true;
  if(!name){nameEl.classList.add('err');setTimeout(function(){nameEl.classList.remove('err');},800);ok=false;}
  if(!stars){pickerEl.style.animation='shake .3s ease';setTimeout(function(){pickerEl.style.animation='';},800);ok=false;}
  if(!text){txtEl.classList.add('err');setTimeout(function(){txtEl.classList.remove('err');},800);ok=false;}
  if(!ok)return;

  var msg=encodeURIComponent(t.waMsg(name,stars,text,prod));
  window.open('https://wa.me/201286332777?text='+msg,'_blank');
};



/* ══════════════════════════════════════════════════════════════