const COUNTRIES=[
  /* ── Arab World ── */
  {f:'🇪🇬',n:{ar:'مصر',en:'Egypt',fr:'Égypte'},        lang:'ar',group:'arab'},
  {f:'🇸🇦',n:{ar:'السعودية',en:'Saudi Arabia',fr:'Arabie Saoudite'},lang:'ar',group:'arab'},
  {f:'🇦🇪',n:{ar:'الإمارات',en:'UAE',fr:'Émirats'},     lang:'ar',group:'arab'},
  {f:'🇰🇼',n:{ar:'الكويت',en:'Kuwait',fr:'Koweït'},     lang:'ar',group:'arab'},
  {f:'🇶🇦',n:{ar:'قطر',en:'Qatar',fr:'Qatar'},          lang:'ar',group:'arab'},
  {f:'🇧🇭',n:{ar:'البحرين',en:'Bahrain',fr:'Bahreïn'},  lang:'ar',group:'arab'},
  {f:'🇴🇲',n:{ar:'عُمان',en:'Oman',fr:'Oman'},          lang:'ar',group:'arab'},
  {f:'🇯🇴',n:{ar:'الأردن',en:'Jordan',fr:'Jordanie'},   lang:'ar',group:'arab'},
  {f:'🇱🇧',n:{ar:'لبنان',en:'Lebanon',fr:'Liban'},      lang:'ar',group:'arab'},
  {f:'🇸🇾',n:{ar:'سوريا',en:'Syria',fr:'Syrie'},        lang:'ar',group:'arab'},
  {f:'🇮🇶',n:{ar:'العراق',en:'Iraq',fr:'Irak'},         lang:'ar',group:'arab'},
  {f:'🇱🇾',n:{ar:'ليبيا',en:'Libya',fr:'Libye'},        lang:'ar',group:'arab'},
  {f:'🇹🇳',n:{ar:'تونس',en:'Tunisia',fr:'Tunisie'},     lang:'fr',group:'arab'},
  {f:'🇩🇿',n:{ar:'الجزائر',en:'Algeria',fr:'Algérie'},  lang:'fr',group:'arab'},
  {f:'🇲🇦',n:{ar:'المغرب',en:'Morocco',fr:'Maroc'},     lang:'fr',group:'arab'},
  {f:'🇾🇪',n:{ar:'اليمن',en:'Yemen',fr:'Yémen'},        lang:'ar',group:'arab'},
  {f:'🇸🇩',n:{ar:'السودان',en:'Sudan',fr:'Soudan'},     lang:'ar',group:'arab'},
  {f:'🇵🇸',n:{ar:'فلسطين',en:'Palestine',fr:'Palestine'},lang:'ar',group:'arab'},
  /* ── Europe / English ── */
  {f:'🇬🇧',n:{ar:'بريطانيا',en:'UK',fr:'Royaume-Uni'},  lang:'en',group:'en'},
  {f:'🇩🇪',n:{ar:'ألمانيا',en:'Germany',fr:'Allemagne'},lang:'en',group:'en'},
  {f:'🇳🇱',n:{ar:'هولندا',en:'Netherlands',fr:'Pays-Bas'},lang:'en',group:'en'},
  {f:'🇸🇪',n:{ar:'السويد',en:'Sweden',fr:'Suède'},      lang:'en',group:'en'},
  {f:'🇺🇸',n:{ar:'أمريكا',en:'USA',fr:'États-Unis'},    lang:'en',group:'en'},
  {f:'🇨🇦',n:{ar:'كندا',en:'Canada',fr:'Canada'},       lang:'en',group:'en'},
  {f:'🇦🇺',n:{ar:'أستراليا',en:'Australia',fr:'Australie'},lang:'en',group:'en'},
  /* ── French-speaking ── */
  {f:'🇫🇷',n:{ar:'فرنسا',en:'France',fr:'France'},      lang:'fr',group:'fr'},
  {f:'🇧🇪',n:{ar:'بلجيكا',en:'Belgium',fr:'Belgique'},  lang:'fr',group:'fr'},
  {f:'🇨🇭',n:{ar:'سويسرا',en:'Switzerland',fr:'Suisse'},lang:'fr',group:'fr'},
];

/* Labels per UI language (before country chosen) */
const CG_LABELS={
  ar:{arab:'العالم العربي 🌙',en:'أوروبا وأمريكا 🌍',fr:'المجال الفرنسي 🇫🇷',
      q:'من أي دولة أنت؟ 🌍',qs:'عشان نتكلم معاك بلغتك'},
  en:{arab:'Arab World 🌙',en:'Europe & Americas 🌍',fr:'French-speaking 🇫🇷',
      q:'Which country are you from? 🌍',qs:'So we can communicate in your language'},
  fr:{arab:'Monde Arabe 🌙',en:'Europe & Amériques 🌍',fr:'Pays francophones 🇫🇷',
      q:'De quel pays venez-vous ? 🌍',qs:'Pour communiquer dans votre langue'},
};

function buildCountryGrid(){
  const grid=document.getElementById('cg-grid');
  if(!grid)return;
  const l=document.documentElement.lang||'ar';
  const lbl=CG_LABELS[l]||CG_LABELS.ar;
  const groups=[
    {key:'arab',label:lbl.arab},
    {key:'en',  label:lbl.en},
    {key:'fr',  label:lbl.fr},
  ];
  grid.innerHTML='';
  groups.forEach(({key,label})=>{
    const grpEl=document.createElement('div');
    grpEl.className='cg-group-lbl';grpEl.textContent=label;
    grid.appendChild(grpEl);
    COUNTRIES.filter(c=>c.group===key).forEach(c=>{
      const btn=document.createElement('button');
      btn.className='cg-btn';
      btn.innerHTML=`<span class="cflag">${c.f}</span><span>${c.n[l]||c.n.ar}</span>`;
      btn.addEventListener('click',()=>{
        applyLanguage(c.lang);
        goStep(2);
      });
      grid.appendChild(btn);
    });
  });
  /* Update question text */
  const qEl=document.querySelector('#s1 .cg-q');
  if(qEl) qEl.innerHTML=lbl.q+'<small>'+lbl.qs+'</small>';
}

/* ── Apply language sitewide ── */
const LANG_COPY={
  ar:{
    dir:'rtl',
    's0-h':'أهلاً! ما اسمك الأول؟ 👋',
    's0-hs':'عشان نتعرف عليك ونخصص تجربتك',
    's0-ph':'اكتب اسمك هنا…',
    's0-btn':'التالي',
    's2-h':'إيه نوعك؟',
    's2-hs':'هنقدر نقترح المنتجات الأنسب ليك',
    's2-f':'بنت','s2-m':'راجل',
    's2-btn':'التالي',
    's3-h':'إيه وصف جسمك؟',
    's3-hs':'دي معلومة مهمة عشان نقترح الصح',
    's3-thin':'نحيف/ة','s3-norm':'طبيعي','s3-over':'زيادة وزن',
    's3-btn':'التالي',
    's4-btn':'شوف توصياتك 🚀',
    's5-btn':'اكتشف المنتجات 🌿',
    'wa-label':'واتساب',
  },
  en:{
    dir:'ltr',
    's0-h':"Hello! What's your first name? 👋",
    's0-hs':'So we can personalise your experience',
    's0-ph':'Type your name here…',
    's0-btn':'Next',
    's2-h':'What is your gender?',
    's2-hs':'To recommend the most suitable products',
    's2-f':'Female','s2-m':'Male',
    's2-btn':'Next',
    's3-h':'How would you describe your body?',
    's3-hs':'Important info to help us suggest the right products',
    's3-thin':'Slim','s3-norm':'Average','s3-over':'Overweight',
    's3-btn':'Next',
    's4-btn':'See your recommendations 🚀',
    's5-btn':'Discover products 🌿',
    'wa-label':'WhatsApp',
  },
  fr:{
    dir:'ltr',
    's0-h':'Bonjour ! Quel est votre prénom ? 👋',
    's0-hs':'Pour personnaliser votre expérience',
    's0-ph':'Tapez votre nom ici…',
    's0-btn':'Suivant',
    's2-h':'Quel est votre genre ?',
    's2-hs':'Pour vous recommander les produits les plus adaptés',
    's2-f':'Femme','s2-m':'Homme',
    's2-btn':'Suivant',
    's3-h':'Comment décrivez-vous votre corps ?',
    's3-hs':'Info importante pour vous suggérer les bons produits',
    's3-thin':'Mince','s3-norm':'Normal','s3-over':'Surpoids',
    's3-btn':'Suivant',
    's4-btn':'Voir mes recommandations 🚀',
    's5-btn':'Découvrir les produits 🌿',
    'wa-label':'WhatsApp',
  },
};

function applyLanguage(lang){
  const c=LANG_COPY[lang]||LANG_COPY.ar;
  const html=document.documentElement;
  html.lang=lang;
  html.dir=c.dir;

  /* helpers */
  const setText=(sel,val)=>{const el=document.querySelector(sel);if(el&&val)el.textContent=val;};
  const setAttr=(sel,attr,val)=>{const el=document.querySelector(sel);if(el&&val)el.setAttribute(attr,val);};

  /* s0 */
  const s0h=document.querySelector('#s0 .step-h');
  if(s0h)s0h.innerHTML=c['s0-h']+'<small>'+c['s0-hs']+'</small>';
  setAttr('#p-name','placeholder',c['s0-ph']);
  const s0btn=document.getElementById('s0-btn');
  if(s0btn)s0btn.innerHTML=c['s0-btn']+' <i class="fas fa-arrow-'+(lang==='ar'?'left':'right')+'" style="font-size:.75rem"></i>';

  /* s1 question */
  buildCountryGrid();

  /* s2 */
  const s2h=document.querySelector('#s2 .step-h');
  if(s2h)s2h.innerHTML=c['s2-h']+'<small>'+c['s2-hs']+'</small>';
  const s2btns=document.querySelectorAll('#s2 .cbtn');
  if(s2btns[0])s2btns[0].innerHTML='<span class="em">👩</span>'+c['s2-f'];
  if(s2btns[1])s2btns[1].innerHTML='<span class="em">👨</span>'+c['s2-m'];
  const s2btn=document.getElementById('s2-btn');
  if(s2btn)s2btn.innerHTML=c['s2-btn']+' <i class="fas fa-arrow-'+(lang==='ar'?'left':'right')+'" style="font-size:.75rem"></i>';

  /* s3 */
  const s3h=document.querySelector('#s3 .step-h');
  if(s3h)s3h.innerHTML=c['s3-h']+'<small>'+c['s3-hs']+'</small>';
  const s3btns=document.querySelectorAll('#s3 .cbtn');
  if(s3btns[0])s3btns[0].innerHTML='<span class="em">🧍</span>'+c['s3-thin'];
  if(s3btns[1])s3btns[1].innerHTML='<span class="em">✅</span>'+c['s3-norm'];
  if(s3btns[2])s3btns[2].innerHTML='<span class="em">⚖️</span>'+c['s3-over'];
  const s3btn=document.getElementById('s3-btn');
  if(s3btn)s3btn.innerHTML=c['s3-btn']+' <i class="fas fa-arrow-'+(lang==='ar'?'left':'right')+'" style="font-size:.75rem"></i>';

  /* s4 */
  const s4btn=document.getElementById('s4-btn');
  if(s4btn)s4btn.textContent=c['s4-btn'];

  /* s5 */
  const s5btn=document.getElementById('s5-btn');
  if(s5btn)s5btn.textContent=c['s5-btn'];

  /* WA FAB label */
  const waLbl=document.querySelector('#wa-fab .wa-lbl');
  if(waLbl)waLbl.textContent=c['wa-label'];

  /* Rebuild social proof toasts to new lang */
  /* (sp-wrap stays, new toasts will use new lang naturally) */
}


/* ══════════ THEME ══════════ */
function initTheme(){const t=localStorage.getItem('pf_theme')||'light';document.documentElement.setAttribute('data-theme',t)}
document.getElementById('theme-btn').addEventListener('click',()=>{
  const cur=document.documentElement.getAttribute('data-theme');
  const next=cur==='light'?'dark':'light';
  document.documentElement.setAttribute('data-theme',next);
  localStorage.setItem('pf_theme',next);
});

/* ══════════ POPUP ══════════ */
let _g=null,_b=null,_p=null;
document.addEventListener('DOMContentLoaded',()=>{
  initTheme();
  try{USER=JSON.parse(localStorage.getItem('pf_u')||'null')}catch{}
  if(USER){closePopup();applyBar();go('home')}
  else{startPopup()}
  initNav();
});

