/* ─────────────────────────────────────────────────────────
   ANIMATIONS — initReveal, initCardTilt, initHeroParallax,
                initHeroCanvas are defined in scripts/main.js
   This file is reserved for standalone animation utilities.
──────────────────────────────────────────────────────── */

/* No standalone animations yet — see scripts/main.js */
