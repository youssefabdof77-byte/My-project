# PUREFORM — Project Structure Guide

## 📁 Folder Overview

```
website/
│
├── index.html                  ← Main entry point — open this in browser
│
├── style/
│   └── main.css                ← All CSS (colors, layout, animations, components)
│
├── scripts/
│   ├── main.js                 ← Core app: navigation, renderers, popup, smart-recs
│   ├── cart.js                 ← Shopping cart IIFE
│   ├── wishlist.js             ← Wishlist IIFE
│   ├── upsell.js               ← Upsell / cross-sell IIFE
│   └── chat.js                 ← Live chat / chatbot IIFE
│
├── components/
│   ├── language-system.js      ← Countries, LANG_COPY, applyLanguage()
│   ├── reviews-data.js         ← All customer review arrays (by product ID)
│   ├── reviews.js              ← Review UI functions (renderReviewsSection etc.)
│   ├── animations.js           ← Standalone animation utilities (reserved)
│   └── before-after.js         ← Before/after section (reserved for future)
│
├── products/
│   │
│   ├── be-strong/              ← Be Strong Hair Kit (b1, b2, b3)
│   │   ├── data.js             ← Product data (name, price, tags, benefits)
│   │   ├── product.html        ← Product page reference
│   │   └── images/             ← Product images folder
│   │
│   ├── enzyme-kit/             ← Enzyme Skin Kit (e1, e2, e3)
│   ├── berries/                ← Berry Body Wash (be1)
│   ├── splash/                 ← Body Splashes (s1, s2)
│   ├── lotion/                 ← Lotion & Gift (l1)
│   ├── package-kit/            ← Full Package Kit (pk1)
│   ├── burnmode/               ← Burnmode Fat Burner (el1)
│   ├── creatine/               ← Corepulse Creatine (el2)
│   ├── maxbulk/                ← MaxBulk Gainer (el3)
│   └── iso-pro/                ← ISO Pro Protein (el4)
│
└── assets/
    └── images/                 ← Shared site images (logo, icons, etc.)
```

---

## ✏️ How to Edit a Product

### Change name, price, or description
1. Open `products/PRODUCT-FOLDER/data.js`
2. Edit any field directly
3. Save — changes reflect immediately on the website

```js
// Example: changing Be Strong Shampoo price
{
  id:   'b1',
  nm:   'Be Strong Shampoo',   // ← product name
  pr:   550,                   // ← sale price (EGP)
  orig: 619,                   // ← original price (shown crossed out)
  best: false,                 // ← true = shows "مطلوب" badge
  badge: '',                   // ← custom badge text (e.g. 'جديد')
  tags: ['جوز الهند', ...],    // ← ingredient pills shown on card
  benefits: [...],             // ← 3 key benefit lines
  uses: [...],                 // ← full use list on product detail page
  problems: ['hair'],          // ← which user problems this targets
}
```

### Add a product image
1. Place the image file in `products/PRODUCT-FOLDER/images/`
2. Update the `img` field in `data.js`:
   ```js
   img: 'products/be-strong/images/shampoo-main.jpg',
   ```

### Add a new product to an existing kit
1. Open `products/PRODUCT-FOLDER/data.js`
2. Copy an existing item block and add it to the `items` array
3. Give it a unique `id` (e.g. `'b4'`)
4. Add its gradient to `CARD_GRADS` at the bottom of the file

### Add a completely new product category
1. Create folder: `products/my-product/`
2. Create `data.js` — copy any existing one as template
3. Create `images/` subfolder
4. Add `<script src="products/my-product/data.js"></script>` to `index.html`

---

## ✏️ How to Edit Reviews

Open `components/reviews-data.js`

```js
// Add a review for product b1 (Be Strong Shampoo):
b1: [
  {n:'Customer Name', s:5, t:'Great product!', d:'منذ أسبوع'},
  // ... existing reviews ...
]
```

---

## 🎨 How to Edit Styles

Open `style/main.css`

CSS variables at the top control the entire color scheme:
```css
:root {
  --gold:  #C8963E;   /* primary accent color */
  --g700:  #2D6A4F;   /* green buttons */
  --g800:  #1B4332;   /* dark green */
  /* ... */
}
```

---

## ⚙️ Script Load Order (index.html)

The scripts load in this exact order:
1. `products/*/data.js` — builds KITS[] and ELEVATE[] arrays
2. `components/language-system.js` — COUNTRIES, LANG_COPY
3. `components/reviews-data.js` — REVIEWS object
4. `components/reviews.js` — review UI functions
5. `scripts/main.js` — core app (navigation, page renderers)
6. `scripts/cart.js` — cart IIFE
7. `scripts/wishlist.js` — wishlist IIFE
8. `scripts/upsell.js` — cross-sell IIFE
9. `scripts/chat.js` — chatbot IIFE

**Important:** Do not change this order. Each file depends on the ones before it.

---

## 🚀 To Disable a Feature

Comment out its `<script>` tag in `index.html`:
```html
<!-- <script src="scripts/chat.js"></script> -->
```

---

## 📞 WhatsApp Number

Search for `201286332777` across all files to find and update the WhatsApp number.
