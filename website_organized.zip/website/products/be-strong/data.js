/**
 * BE STRONG — Hair Care Collection
 * Products: Shampoo (b1), Conditioner (b2), Hair Mist (b3)
 *
 * To edit a product: change any value below and save.
 * Images: place files in products/be-strong/images/
 */

window.KITS = window.KITS || [];

window.KITS.push({
  key: 'strong',
  label: 'Be Strong',
  icon: '💪',
  tag: 'عناية الشعر',
  color: '#1B4332',
  items: [

    /* ─── b1: Be Strong Shampoo ─────────────────── */
    {
      id: 'b1',
      nm: 'Be Strong Shampoo',
      pr: 550,
      orig: 619,
      best: false,
      badge: '',
      em: '',
      img: 'New folder/WhatsApp Image 2026-02-25 at 10.14.09 AM (2).jpeg',
      tags: ['جوز الهند', 'الريحان', 'الشيكاكاي', 'جنزبيل هندي', 'فيتامين هـ'],
      benefits: ['يقلل التساقط بشكل ملحوظ', 'لمعان طبيعي وصحي', 'يرطب فروة الرأس'],
      uses: [
        'تغذية كاملة للشعر من الجذور للأطراف',
        'يمنح لمعان طبيعي وصحي',
        'يوفر ترطيب عميق لفروة الرأس',
        'يقلل فقدان البروتين الطبيعي للشعر',
        'يعزز قوة الشعر ويقلل التساقط',
        'مناسب لكل أنواع الشعر',
      ],
      macros: [],
      problems: ['hair'],
    },

    /* ─── b2: Be Strong Conditioner ─────────────── */
    {
      id: 'b2',
      nm: 'Be Strong Conditioner',
      pr: 550,
      orig: 619,
      best: true,
      badge: 'الأكثر طلباً',
      em: '',
      img: 'New folder/WhatsApp Image 2026-02-25 at 10.13.55 AM.jpeg',
      tags: ['الصبار', 'زيت الأرجان', 'زبدة الشيا', 'الكرياتين', 'جوز الهند'],
      benefits: ['يصلح التلف ويقوي الشعر', 'حماية من أشعة الشمس', 'يقلل التقصف ٩٠٪'],
      uses: [
        'إصلاح التلف',
        'تقوية الشعر',
        'حماية من الشمس',
        'تقليل التقصف والتكسر',
        'تجديد فروة الرأس',
        'علاج الشعر الجاف',
      ],
      macros: [],
      problems: ['hair'],
    },

    /* ─── b3: Be Strong Hair Mist ────────────────── */
    {
      id: 'b3',
      nm: 'Be Strong Hair Mist',
      pr: 499,
      orig: 568,
      best: true,
      badge: 'مميز',
      em: '',
      img: 'New folder/WhatsApp Image 2026-03-02 at 3.05.24 PM.jpeg',
      tags: ['الصبار', 'الأرجان', 'جوز الهند', 'الكرياتين', 'زيت اللوز'],
      benefits: ['ترطيب طوال اليوم', 'يمنع الجفاف والتكسر', 'يعزز اللمعان الطبيعي'],
      uses: [
        'ترطيب طوال اليوم',
        'حماية من التلف',
        'الحفاظ على البروتين الطبيعي',
        'منع الجفاف',
        'تعزيز اللمعان',
        'تقليل التكسر',
      ],
      macros: [],
      problems: ['hair'],
    },

  ],
});

/* ── Card Gradient Colors ─────────────────────────── */
window.CARD_GRADS = window.CARD_GRADS || {};
Object.assign(window.CARD_GRADS, {
  b1: 'linear-gradient(135deg,#1B4332,#2D6A4F)',
  b2: 'linear-gradient(135deg,#155235,#38826A)',
  b3: 'linear-gradient(135deg,#1D5C40,#47A374)',
});
