/**
 * ENZYME KIT — Product Data
 * Kit key: 'enzyme'
 *
 * HOW TO EDIT:
 *   - Change any field below and save this file.
 *   - To add a product: copy an item block and update its id.
 *   - To remove a product: delete its entire object from the items array.
 *   - Images: place files in products/enzyme-kit/images/
 */

window.KITS = window.KITS || [];

window.KITS.push({
  key: 'enzyme',
  label: 'Enzyme Kit',
  icon: '🌸',
  tag: 'عناية البشرة',
  color: '#4a1942',
  items: [

    /* ─── e1: Bloushing Blossom Body Wash ───────────── */
    {
      id:       'e1',
      nm:       'Bloushing Blossom Body Wash',
      pr:       399,          // price (EGP)
      orig:     468,          // original price before discount
      best:     false,
      badge:    '',
      em:       '',
      img:      'New folder/WhatsApp Image 2026-02-25 at 10.14.09 AM (1).jpeg',
      tags:     ['بابايا', 'أناناس', 'زبدة الشيا', 'عشب الليمون'],
      benefits: ['يرطب ويجدد خلايا البشرة', 'يزيل الجلد الميت بلطف', 'يفتح آثار الشمس'],
      uses:     ['مكافحة الجفاف', 'ترطيب عميق', 'تجديد خلايا البشرة', 'إزالة الجلد الميت', 'تفتيح آثار الشمس', 'تنظيف لطيف دون تجفيف'],
      macros:   [],
      problems: ['skin'],
    },

    /* ─── e2: Splash Face Scrub ─────────────────────── */
    {
      id:       'e2',
      nm:       'Splash Face Scrub',
      pr:       499,          // price (EGP)
      orig:     568,          // original price before discount
      best:     false,
      badge:    '',
      em:       '',
      img:      'New folder/WhatsApp Image 2026-02-25 at 10.13.59 AM.jpeg',
      tags:     ['بابايا', 'إنزيمات البابايا', 'حبيبات تقشير لطيفة'],
      benefits: ['يقشر الخلايا الميتة بلطف', 'يصفي وينعم البشرة', 'يمنع حب الشباب'],
      uses:     ['تقشير لطيف', 'إزالة الخلايا الميتة', 'تحسين ملمس البشرة', 'الوقاية من حب الشباب', 'التنقية العميقة'],
      macros:   [],
      problems: ['skin', 'acne'],
    },

    /* ─── e3: Splash Face Wash ──────────────────────── */
    {
      id:       'e3',
      nm:       'Splash Face Wash',
      pr:       499,          // price (EGP)
      orig:     568,          // original price before discount
      best:     true,
      badge:    'الأفضل للوجه',
      em:       '',
      img:      'New folder/WhatsApp Image 2026-02-25 at 10.13.52 AM.jpeg',
      tags:     ['إنزيمات الفاكهة', 'الصبار', 'حمض الهيالورونيك'],
      benefits: ['تنظيف عميق بدون جفاف', 'يوحد لون البشرة', 'مضاد للأكسدة'],
      uses:     ['تنظيف عميق', 'توحيد لون البشرة', 'مضاد للأكسدة', 'حماية خلايا البشرة'],
      macros:   [],
      problems: ['skin', 'acne'],
    },

  ],
});

/* ── Card Gradient Colors ─────────────────────────── */
window.CARD_GRADS = window.CARD_GRADS || {};
Object.assign(window.CARD_GRADS, {
  e1: 'linear-gradient(135deg,#4A1942,#7B3472)',
  e2: 'linear-gradient(135deg,#5C1A4A,#8B4060)',
  e3: 'linear-gradient(135deg,#3A2060,#6A4A9A)',
});