/**
 * BURNMODE TABLETS — Product Data
 * Product ID: 'el1'  |  Category: Elevate (Men's Supplements)
 *
 * HOW TO EDIT:
 *   - Change any field below and save.
 *   - Images: place files in products/burnmode/images/
 */

window.ELEVATE = window.ELEVATE || [];

window.ELEVATE.push({
  id:       'el1',
  nm:       'Burnmode Tablets',
  pr:       1100,          // price (EGP)
  orig:     1169,          // original price before discount
  best:     false,
  badge:    '',
  em:       '🔥',
  img:      '',                   // place image path here e.g. 'products/burnmode/images/main.jpg'
  tags:     ['L-كارنيتين', 'كروم', 'جرين تي'],
  benefits: ['حرق الدهون بدون فقدان العضلة', 'زيادة الطاقة والتركيز', 'يكبح الشهية بشكل طبيعي'],
  uses:     ['حرق الدهون', 'تحسين الأداء الرياضي', 'تقليل الشهية', 'رفع مستوى الطاقة', 'تحسين التركيز', 'المساعدة في فقدان الوزن'],
  macros:   [{lb: 'بروتين', v: '0 g'}, {lb: 'كارنيتين', v: '500 mg'}, {lb: 'كروم', v: '200 mcg'}],
  problems: ['fat', 'energy'],
});

/* ── Card Gradient Color ──────────────────────────── */
window.CARD_GRADS = window.CARD_GRADS || {};
window.CARD_GRADS['el1'] = 'linear-gradient(135deg,#7B1D1D,#B84040)';
