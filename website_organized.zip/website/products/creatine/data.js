/**
 * COREPULSE CREATINE — Product Data
 * Product ID: 'el2'  |  Category: Elevate (Men's Supplements)
 *
 * HOW TO EDIT:
 *   - Change any field below and save.
 *   - Images: place files in products/creatine/images/
 */

window.ELEVATE = window.ELEVATE || [];

window.ELEVATE.push({
  id:       'el2',
  nm:       'Corepulse Creatine',
  pr:       1351,          // price (EGP)
  orig:     1420,          // original price before discount
  best:     true,
  badge:    'الأكثر طلباً',
  em:       '💪',
  img:      '',                   // place image path here e.g. 'products/creatine/images/main.jpg'
  tags:     ['كرياتين مونوهيدرات', 'بيتا ألانين', 'تورين'],
  benefits: ['يزيد القوة والقدرة على التحمل', 'يعزز بناء الكتلة العضلية', 'يسرع التعافي بعد التمرين'],
  uses:     ['زيادة القوة', 'بناء العضلة', 'تسريع التعافي', 'تحسين الأداء الرياضي', 'زيادة حجم العضلات'],
  macros:   [{lb: 'كرياتين', v: '5 g'}, {lb: 'بيتا ألانين', v: '3.2 g'}, {lb: 'تورين', v: '1 g'}],
  problems: ['thinness', 'energy'],
});

/* ── Card Gradient Color ──────────────────────────── */
window.CARD_GRADS = window.CARD_GRADS || {};
window.CARD_GRADS['el2'] = 'linear-gradient(135deg,#1B2A4A,#3A6090)';
