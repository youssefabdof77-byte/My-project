/**
 * ISO PRO PROTEIN — Product Data
 * Product ID: 'el4'  |  Category: Elevate (Men's Supplements)
 *
 * HOW TO EDIT:
 *   - Change any field below and save.
 *   - Images: place files in products/iso-pro/images/
 */

window.ELEVATE = window.ELEVATE || [];

window.ELEVATE.push({
  id:       'el4',
  nm:       'ISO Pro Protein',
  pr:       1800,          // price (EGP)
  orig:     1869,          // original price before discount
  best:     true,
  badge:    'الأفضل جودة',
  em:       '🥛',
  img:      '',                   // place image path here e.g. 'products/iso-pro/images/main.jpg'
  tags:     ['واي بروتين معزول', 'BCAA', 'جلوتامين'],
  benefits: ['25g بروتين نقي لكل وجبة', 'ترميم سريع للعضلات', 'خالي من الدهون والسكريات'],
  uses:     ['بناء العضلة', 'ترميم الأنسجة', 'زيادة قوة العضلة', 'التعافي بعد التمرين', 'دعم نمو العضلات'],
  macros:   [{lb: 'سعرات', v: '120 kcal'}, {lb: 'بروتين', v: '25 g'}, {lb: 'دهون', v: '1.5 g'}, {lb: 'كربوهيدرات', v: '3 g'}],
  problems: ['thinness', 'energy'],
});

/* ── Card Gradient Color ──────────────────────────── */
window.CARD_GRADS = window.CARD_GRADS || {};
window.CARD_GRADS['el4'] = 'linear-gradient(135deg,#3A1E2A,#8A4060)';
