/**
 * LOTION & GIFT — Product Data
 * Kit key: 'lotion'
 *
 * HOW TO EDIT:
 *   - Change any field and save.
 *   - Images: place files in products/lotion/images/
 */

window.KITS = window.KITS || [];
window.KITS.push({
  key: 'lotion',
  label: 'Lotion & Gift',
  icon: '🎁',
  tag: 'لوشن وهدايا',
  color: '#1B3A4B',
  items: [

    /* ─── l1: Your Love Body Lotion */
    {
      id: 'l1',
      nm: 'Your Love Body Lotion',
      pr: 599,  // price (EGP)
      orig: 668,
      best: true,
      badge: 'الأعلى تقييماً',
      em: '',
      img: 'New folder/WhatsApp Image 2026-02-25 at 10.13.38 AM.jpeg',
      tags: ['اللافندر', 'جوز الهند', 'الزيتون', 'زبدة الشيا', 'فيتامين هـ'],
      benefits: ['ترطيب يدوم 12+ ساعة', 'يقلل الترهلات والخطوط', 'حماية كاملة من UV'],
      uses: ['ترطيب عميق', 'تقليل الترهلات', 'مضاد للفطريات والبكتيريا', 'حماية من الأشعة', 'إزالة الخطوط', 'تقوية حاجز البشرة', 'منع الجفاف الشديد'],
      problems: ['skin', 'other'],
    },

  ],
});

window.CARD_GRADS = window.CARD_GRADS || {};
Object.assign(window.CARD_GRADS, {
  l1: 'linear-gradient(135deg,#1B3A4B,#3A7A9A)',
});