/**
 * BODY SPLASHES — Product Data
 * Kit key: 'splash'
 *
 * HOW TO EDIT:
 *   - Change any field and save.
 *   - Images: place files in products/splash/images/
 */

window.KITS = window.KITS || [];
window.KITS.push({
  key: 'splash',
  label: 'Body Splashes',
  icon: '✨',
  tag: 'بخاخات الجسم',
  color: '#3D2C1E',
  items: [

    /* ─── s1: Wiseman Body Splash */
    {
      id: 's1',
      nm: 'Wiseman Body Splash',
      pr: 659,  // price (EGP)
      orig: 728,
      best: true,
      badge: 'الأقوى مبيعاً',
      em: '',
      img: 'New folder/WhatsApp Image 2026-02-25 at 10.14.02 AM.jpeg',
      tags: ['خشب الصندل الهندي', 'بانثينول', 'فيتامين هـ'],
      benefits: ['ترطيب عميق طويل الأمد', 'يعالج حب الشباب والحكة', 'يساعد في التئام الجروح'],
      uses: ['ترطيب عميق', 'الوقاية من علامات الشيخوخة', 'علاج حب الشباب', 'علاج الحكة', 'علاج حروق الشمس', 'المساعدة في التئام الجروح', 'المساعدة في حالات الأكزيما', 'رائحة ثابتة ومنعشة'],
      problems: ['skin', 'acne'],
    },

    /* ─── s2: Blind Date Body Splash */
    {
      id: 's2',
      nm: 'Blind Date Body Splash',
      pr: 659,  // price (EGP)
      orig: 728,
      best: false,
      badge: '',
      em: '',
      img: 'New folder/WhatsApp Image 2026-02-25 at 10.13.44 AM.jpeg',
      tags: ['الورد', 'الياسمين', 'المسك'],
      benefits: ['رائحة فواحة تدوم طويلاً', 'ترطيب وإشراقة', 'مثالي للبشرة المختلطة'],
      uses: ['ترطيب', 'رائحة دائمة', 'حماية البشرة'],
      problems: ['skin', 'other'],
    },

  ],
});

window.CARD_GRADS = window.CARD_GRADS || {};
Object.assign(window.CARD_GRADS, {
  s1: 'linear-gradient(135deg,#3D2C1E,#7A5535)',
  s2: 'linear-gradient(135deg,#4A2A28,#8A4A45)',
});