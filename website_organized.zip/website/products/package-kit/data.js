/**
 * PACKAGE KIT — Product Data
 * Kit key: 'package'
 *
 * HOW TO EDIT:
 *   - Change any field and save.
 *   - Images: place files in products/package-kit/images/
 */

window.KITS = window.KITS || [];
window.KITS.push({
  key: 'package',
  label: 'Package Kit',
  icon: '🎀',
  tag: 'الكيت الكاملة',
  color: '#3D1E3A',
  items: [

    /* ─── pk1: Package Kit الكاملة */
    {
      id: 'pk1',
      nm: 'Package Kit الكاملة',
      pr: 1250,  // price (EGP)
      orig: 1319,
      best: false,
      badge: 'هدية مثالية',
      em: '',
      img: '',
      tags: ['عينات جميع المنتجات', 'شنطة أنيقة'],
      benefits: ['تجربة كاملة لجميع المنتجات', 'هدية مميزة ومفيدة', 'توفير أكبر في الأسعار'],
      uses: ['مثالي للتجربة الكاملة', 'مناسب كهدية فاخرة', 'طريقة رائعة لاكتشاف جميع المنتجات'],
      problems: ['hair', 'skin', 'other'],
    },

  ],
});

window.CARD_GRADS = window.CARD_GRADS || {};
Object.assign(window.CARD_GRADS, {
  pk1: 'linear-gradient(135deg,#3D1E3A,#7A3A70)',
});