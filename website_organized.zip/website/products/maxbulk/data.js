/**
 * MAXBULK GAINER — Product Data
 * Product ID: 'el3'  |  Category: Elevate (Men's Supplements)
 *
 * HOW TO EDIT:
 *   - Change any field below and save.
 *   - Images: place files in products/maxbulk/images/
 */

window.ELEVATE = window.ELEVATE || [];

window.ELEVATE.push({
  id:       'el3',
  nm:       'MaxBulk Gainer',
  pr:       1500,          // price (EGP)
  orig:     1569,          // original price before discount
  best:     false,
  badge:    'جديد',
  em:       '🏋️',
  img:      '',                   // place image path here e.g. 'products/maxbulk/images/main.jpg'
  tags:     ['وايت ميز', 'بروتين مركب', 'فيتامينات'],
  benefits: ['زيادة الوزن وبناء الكتلة', 'طاقة مستدامة طوال اليوم', 'يحتوي على 9 أحماض أمينية أساسية'],
  uses:     ['زيادة الوزن', 'بناء الكتلة العضلية', 'طاقة مستدامة', 'تغذية شاملة', 'دعم نمو العضلات'],
  macros:   [{lb: 'سعرات', v: '400 kcal'}, {lb: 'بروتين', v: '25 g'}, {lb: 'كربوهيدرات', v: '62 g'}],
  problems: ['thinness'],
});

/* ── Card Gradient Color ──────────────────────────── */
window.CARD_GRADS = window.CARD_GRADS || {};
window.CARD_GRADS['el3'] = 'linear-gradient(135deg,#2A3A1E,#5A7A30)';
