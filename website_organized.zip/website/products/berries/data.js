/**
 * BERRIES COLLECTION — Product Data
 * Kit key: 'berries'
 *
 * HOW TO EDIT:
 *   - Change any field and save.
 *   - Images: place files in products/berries/images/
 */

window.KITS = window.KITS || [];
window.KITS.push({
  key: 'berries',
  label: 'Berries Collection',
  icon: '🍓',
  tag: 'عناية البشرة',
  color: '#7B1D45',
  items: [

    /* ─── be1: Berry Go Round Body Wash */
    {
      id: 'be1',
      nm: 'Berry Go Round Body Wash',
      pr: 399,  // price (EGP)
      orig: 468,
      best: false,
      badge: '',
      em: '',
      img: 'New folder/WhatsApp Image 2026-02-25 at 10.13.48 AM.jpeg',
      tags: ['توت بري', 'فراولة', 'جنزبيل', 'زبدة الشيا'],
      benefits: ['ترطيب عميق وإشراقة', 'تفتيح طبيعي', 'يجدد الخلايا ويحسن اللون'],
      uses: ['ترطيب عميق', 'تحسين مظهر الخطوط', 'تفتيح طبيعي', 'تجديد خلايا البشرة', 'تصحيح لون البشرة', 'منح إشراقة طبيعية'],
      problems: ['skin'],
    },

  ],
});

window.CARD_GRADS = window.CARD_GRADS || {};
Object.assign(window.CARD_GRADS, {
  be1: 'linear-gradient(135deg,#7B1D45,#B84070)',
});