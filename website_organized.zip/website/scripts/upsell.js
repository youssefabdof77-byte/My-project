
   UPSELL / CROSS-SELL SYSTEM
══════════════════════════════════════════════════════════════ */
(function(){
  /* Cross-sell map: product → related product IDs */
  var XSELL={
    b1:['b2','b3','pk1'],b2:['b1','b3','pk1'],b3:['b1','b2'],
    e1:['e2','e3','be1'],e2:['e1','e3','s1'],e3:['e1','e2','be1'],
    be1:['e1','e3','l1'],s1:['e1','l1','be1'],s2:['s1','l1'],l1:['s1','be1','e1'],
    pk1:['b1','b2','b3'],
    el1:['el2','el4','el3'],el2:['el1','el4','el3'],
    el3:['el2','el4','el1'],el4:['el1','el2','el3'],
  };

  var T={
    ar:{title:'يشتريها العملاء معاه 🛒',sub:'ممكن يفيدك مع اللي اخترته',atc:'أضف للسلة',dismiss:'لأ شكراً'},
    en:{title:'Customers also buy 🛒',sub:'Often paired with your selection',atc:'Add to Cart',dismiss:'No thanks'},
    fr:{title:'Les clients achètent aussi 🛒',sub:'Souvent associé à votre sélection',atc:'Ajouter',dismiss:'Non merci'},
  };
  function L(){return T[document.documentElement.lang||'ar']||T.ar;}

  window.showUpsell=function(addedId){
    var related=(XSELL[addedId]||[]).filter(function(id){
      return window.PRODUCTS&&window.PRODUCTS[id];
    }).slice(0,4);
    if(!related.length)return;
    var lc=L();
    var titleEl=document.getElementById('upsell-title');
    var subEl=document.getElementById('upsell-sub');
    var dismissEl=document.getElementById('upsell-dismiss-txt');
    if(titleEl)titleEl.textContent=lc.title;
    if(subEl)subEl.textContent=lc.sub;
    if(dismissEl)dismissEl.textContent=lc.dismiss;

    var grid=document.getElementById('upsell-grid');
    if(!grid)return;
    grid.innerHTML=related.map(function(id){
      var p=window.PRODUCTS[id];
      var img=p.img
        ?'<img src="'+p.img+'" alt="'+p.nm+'" loading="lazy">'
        :'<span style="font-size:2rem">'+(p.em||'🌿')+'</span>';
      return '<div class="upsell-card">'
        +'<div class="upsell-card-img">'+img+'</div>'
        +'<div class="upsell-card-body">'
        +  '<div class="upsell-card-nm">'+p.nm+'</div>'
        +  '<div class="upsell-card-pr">'+p.pr.toLocaleString()+' جنيه</div>'
        +  '<button class="upsell-card-atc" id="uatc-'+id+'" onclick="upsellAdd(\''+id+'\')">'
        +    '<i class="fas fa-plus" style="font-size:.65rem"></i> '+lc.atc
        +  '</button>'
        +'</div>'
        +'</div>';
    }).join('');

    document.getElementById('upsell-overlay').classList.add('open');
    document.getElementById('upsell-modal').classList.add('open');
    document.body.style.overflow='hidden';
  };

  window.upsellAdd=function(id){
    window.addToCart(id);
    var btn=document.getElementById('uatc-'+id);
    var lc=L();
    if(btn){btn.classList.add('added');btn.textContent='✓ '+lc.atc;}
  };

  window.closeUpsell=function(){
    document.getElementById('upsell-overlay').classList.remove('open');
    document.getElementById('upsell-modal').classList.remove('open');
    document.body.style.overflow='';
  };

  /* Hook into addToCart to trigger upsell 1.2s after add */
  var _origATC=window.addToCart;
  window.addToCart=function(id){
    _origATC(id);
    /* Only show upsell if modal not already open */
    if(!document.getElementById('upsell-modal').classList.contains('open')){
      setTimeout(function(){window.showUpsell(id);},900);
    }
  };
})();

/* ══════════════════════════════════════════════════════════════