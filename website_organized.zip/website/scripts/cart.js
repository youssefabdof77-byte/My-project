
   PUREFORM CART SYSTEM  (v2 — fixed)
══════════════════════════════════════════════════════ */
(function(){

const SHIPPING=70;

/* ── Translations ── */
const CT={
  ar:{
    title:'السلة',atc:'أضف للسلة',added:'تمت الإضافة ✓',
    empty:'سلتك فارغة',emptyHint:'أضف منتجات لتبدأ طلبك',
    confirm:'تأكيد الطلب عبر واتساب',
    total:'الإجمالي',subtotal:'المجموع',
    shipping:'الشحن',currency:'جنيه',
    items:function(n){return n===1?'منتج واحد':n+' منتجات';},
    waMsg:function(lines,sub,ship,total){
      return 'مرحباً،\n\nعايز أطلب:\n\n'+lines+'\n\n━━━━━━━━━━━━━━━\n'
            +'💰 المجموع: '+sub+' جنيه\n'
            +'🚚 الشحن: '+ship+' جنيه\n'
            +'✅ الإجمالي: '+total+' جنيه\n\nأرجو التأكيد 🌿';
    }
  },
  en:{
    title:'Cart',atc:'Add to Cart',added:'Added ✓',
    empty:'Your cart is empty',emptyHint:'Add products to start your order',
    confirm:'Confirm Order via WhatsApp',
    total:'Total',subtotal:'Subtotal',
    shipping:'Shipping',currency:'EGP',
    items:function(n){return n===1?'1 item':n+' items';},
    waMsg:function(lines,sub,ship,total){
      return 'Hello,\n\nI\'d like to order:\n\n'+lines+'\n\n━━━━━━━━━━━━━━━\n'
            +'💰 Subtotal: '+sub+' EGP\n'
            +'🚚 Shipping: '+ship+' EGP\n'
            +'✅ Total: '+total+' EGP\n\nPlease confirm 🌿';
    }
  },
  fr:{
    title:'Panier',atc:'Ajouter au panier',added:'Ajouté ✓',
    empty:'Votre panier est vide',emptyHint:'Ajoutez des produits pour commencer',
    confirm:'Confirmer via WhatsApp',
    total:'Total',subtotal:'Sous-total',
    shipping:'Livraison',currency:'EGP',
    items:function(n){return n===1?'1 article':n+' articles';},
    waMsg:function(lines,sub,ship,total){
      return 'Bonjour,\n\nJe voudrais commander:\n\n'+lines+'\n\n━━━━━━━━━━━━━━━\n'
            +'💰 Sous-total: '+sub+' EGP\n'
            +'🚚 Livraison: '+ship+' EGP\n'
            +'✅ Total: '+total+' EGP\n\nMerci de confirmer 🌿';
    }
  }
};

function L(){return CT[document.documentElement.lang||'ar']||CT.ar;}

/* expose cartT so makeCard template strings can call it */
window.cartT=function(key){return L()[key]||key;};

/* ── State: {id: qty} ── */
var CART={};
function save(){try{sessionStorage.setItem('pf_cart',JSON.stringify(CART));}catch(e){}}
function load(){try{var d=sessionStorage.getItem('pf_cart');if(d)CART=JSON.parse(d);}catch(e){}}
load();

/* ── Get product safely ── */
function prod(id){
  return (window.PRODUCTS&&window.PRODUCTS[id])||null;
}

/* ── Totals ── */
function totalQty(){
  return Object.values(CART).reduce(function(s,q){return s+q;},0);
}
function subtotalPrice(){
  return Object.entries(CART).reduce(function(s,entry){
    var p=prod(entry[0]);
    return s+(p?p.pr*entry[1]:0);
  },0);
}
function grandTotal(){
  var sub=subtotalPrice();
  return sub>0?sub+SHIPPING:0;
}

/* ── Nav badge ── */
function updateBadge(){
  var el=document.getElementById('cart-count');
  if(!el)return;
  var n=totalQty();
  el.textContent=n>99?'99+':String(n);
  el.classList.toggle('vis',n>0);
  if(n>0){el.classList.remove('pop');void el.offsetWidth;el.classList.add('pop');}
}

/* ── Add ── */
window.addToCart=function(id){
  CART[id]=(CART[id]||0)+1;
  save();updateBadge();
  /* button feedback */
  var btn=document.getElementById('atc-'+id);
  if(btn){
    btn.classList.add('added');
    var span=btn.querySelector('span');
    if(span)span.textContent=L().added;
    clearTimeout(btn._t);
    btn._t=setTimeout(function(){
      btn.classList.remove('added');
      if(span)span.textContent=L().atc;
    },1800);
  }
  /* live-update if drawer is open */
  if(document.getElementById('cart-drawer').classList.contains('open'))renderCartItems();
};

/* ── Remove ── */
window.removeCartItem=function(id){
  delete CART[id];save();updateBadge();renderCartItems();
};

/* ── Qty change ── */
window.changeQty=function(id,delta){
  var n=(CART[id]||0)+delta;
  if(n<=0){delete CART[id];}else{CART[id]=n;}
  save();updateBadge();renderCartItems();
};

/* ── Render drawer contents ── */
function renderCartItems(){
  var list=document.getElementById('cart-items-list');
  var ftr=document.getElementById('cart-ftr');
  var totalsEl=document.getElementById('cart-totals');
  var countEl=document.getElementById('cart-item-count-txt');
  if(!list)return;

  var lc=L();
  var ids=Object.keys(CART).filter(function(id){return CART[id]>0;});

  if(countEl)countEl.textContent=lc.items(totalQty());

  if(ids.length===0){
    list.innerHTML='<div class="cart-empty">'
      +'<span class="cart-empty-ico">🛍️</span>'
      +'<div>'+lc.empty+'</div>'
      +'<div style="font-size:.75rem;opacity:.65">'+lc.emptyHint+'</div>'
      +'</div>';
    if(ftr)ftr.style.display='none';
    return;
  }
  if(ftr)ftr.style.display='';

  /* Item rows */
  list.innerHTML=ids.map(function(id){
    var p=prod(id);
    if(!p)return'';
    var qty=CART[id];
    var lineTotal=(p.pr*qty).toLocaleString('ar-EG');
    var imgHtml=p.img
      ?'<img src="'+p.img+'" alt="'+p.nm+'" loading="lazy">'
      :'<span style="font-size:1.4rem">'+(p.em||'🌿')+'</span>';
    return '<div class="ci" id="ci-'+id+'">'
      +'<div class="ci-img">'+imgHtml+'</div>'
      +'<div class="ci-body">'
      +  '<div class="ci-name">'+p.nm+'</div>'
      +  '<div class="ci-kit">'+(p.kit||'')+'</div>'
      +  '<div class="ci-price">'+p.pr.toLocaleString('ar-EG')+' <span style="font-size:.65rem;font-weight:400">'+lc.currency+'</span></div>'
      +'</div>'
      +'<div class="ci-right">'
      +  '<button class="ci-del" onclick="removeCartItem(\''+id+'\')"><i class="fas fa-trash-alt"></i></button>'
      +  '<div class="ci-qty">'
      +    '<button class="ci-qty-btn" onclick="changeQty(\''+id+'\',-1)">−</button>'
      +    '<span class="ci-qty-num">'+qty+'</span>'
      +    '<button class="ci-qty-btn" onclick="changeQty(\''+id+'\',1)">+</button>'
      +  '</div>'
      +  '<div style="font-size:.7rem;color:var(--ink4);text-align:center">'+lineTotal+' '+lc.currency+'</div>'
      +'</div>'
      +'</div>';
  }).join('');

  /* Totals block */
  var sub=subtotalPrice();
  var grand=grandTotal();
  if(totalsEl){
    totalsEl.innerHTML=
      '<div class="cart-total-row">'
      +  '<span>'+lc.subtotal+'</span>'
      +  '<span class="cart-total-val">'+sub.toLocaleString('ar-EG')+' '+lc.currency+'</span>'
      +'</div>'
      +'<div class="cart-total-row">'
      +  '<span>'+lc.shipping+'</span>'
      +  '<span style="color:var(--g600);font-weight:600">'+SHIPPING.toLocaleString('ar-EG')+' '+lc.currency+' 🚚</span>'
      +'</div>'
      +'<div class="cart-total-row main">'
      +  '<span>'+lc.total+'</span>'
      +  '<span class="cart-total-val">'+grand.toLocaleString('ar-EG')+' '+lc.currency+'</span>'
      +'</div>';
  }

  var cBtn=document.getElementById('cart-confirm-txt');
  if(cBtn)cBtn.textContent=lc.confirm;
}

/* ── Open/close ── */
window.openCart=function(){
  renderCartItems();
  document.getElementById('cart-drawer').classList.add('open');
  document.getElementById('cart-overlay').classList.add('open');
  document.body.style.overflow='hidden';
  var tEl=document.getElementById('cart-title-txt');
  if(tEl)tEl.textContent=L().title;
};
window.closeCart=function(){
  document.getElementById('cart-drawer').classList.remove('open');
  document.getElementById('cart-overlay').classList.remove('open');
  document.body.style.overflow='';
};

/* ── Confirm order → WhatsApp ── */
window.confirmOrder=function(){
  var lc=L();
  var ids=Object.keys(CART).filter(function(id){return CART[id]>0;});
  if(!ids.length)return;
  var lines=ids.map(function(id){
    var p=prod(id);
    if(!p)return'';
    var line='• '+p.nm+' × '+CART[id]+' = '+( p.pr*CART[id] ).toLocaleString('ar-EG')+' '+lc.currency;
    return line;
  }).filter(Boolean).join('\n');
  var sub=subtotalPrice().toLocaleString('ar-EG');
  var ship=SHIPPING.toLocaleString('ar-EG');
  var grand=grandTotal().toLocaleString('ar-EG');
  var msg=encodeURIComponent(lc.waMsg(lines,sub,ship,grand));
  window.open('https://wa.me/201286332777?text='+msg,'_blank');
};

/* ── Detail-page ATC feedback ── */
window.updateAtcDetail=function(id){
  var btn=document.getElementById('atc-detail-'+id);
  var txt=document.getElementById('atc-detail-txt');
  if(!btn||!txt)return;
  btn.classList.add('added');
  txt.textContent=L().added;
  clearTimeout(btn._t);
  btn._t=setTimeout(function(){btn.classList.remove('added');txt.textContent=L().atc;},2000);
};

/* ── Init ── */
updateBadge();

/* ── Sync after language change ── */
var _prevApplyLang=window.applyLanguage;
if(typeof _prevApplyLang==='function'){
  window.applyLanguage=function(lang){
    _prevApplyLang(lang);
    updateBadge();
    if(document.getElementById('cart-drawer').classList.contains('open'))renderCartItems();
  };
}

})();



/* ══════════════════════════════════════════════════
   REVIEW SYSTEM
══════════════════════════════════════════════════ */

