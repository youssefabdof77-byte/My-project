
   LIVE CHAT / CHATBOT
══════════════════════════════════════════════════════════════ */
(function(){
  var open=false;
  var msgId=0;

  var KB={
    ar:{
      greet:'أهلاً! 👋 أنا مساعد PUREFORM. ممكن أساعدك في اختيار المنتج المناسب ليك. إيه اللي بتدور عليه؟',
      quick:['منتجات الشعر 💆','حرق الدهون 🔥','بروتين وكرياتين 💪','الشحن والأسعار 🚚','تواصل مع الفريق 📞'],
      bot_name:'مساعد PUREFORM',status_txt:'متاح الآن',input_ph:'اكتب سؤالك…',
      wa_cta:'تحدث مع فريقنا عبر واتساب 💬',
      responses:{
        'شعر':'بالنسبة للشعر، Be Strong Kit هي الأفضل 💪 شامبو + مكيف + ميست — بيقلل التساقط ويغذي الشعر من الجذور. شوف صفحة RZN Beauty! 🌿',
        'hair':'بالنسبة للشعر، Be Strong Kit هي الأفضل 💪',
        'دهون':'Burnmode Tablets هو الأقوى لحرق الدهون 🔥 مكون من مستخلصات طبيعية، يرفع طاقتك وحرق دهونك في نفس الوقت!',
        'تخسيس':'Burnmode Tablets هو الأقوى لحرق الدهون 🔥',
        'بروتين':'ISO Pro Protein مثالي للبناء العضلي 💪 وممكن تضيف Corepulse Creatine معاه للنتائج الأسرع!',
        'كرياتين':'Corepulse Creatine يزود قوتك في التمرين ويسرع نتائجك 💪',
        'شحن':'الشحن 70 جنيه لجميع محافظات مصر 🚚 وشحن دولي متاح لأكثر من 16 دولة!',
        'سعر':'الأسعار تبدأ من 399 جنيه. كل منتج بيوفر عليك مقارنة بالسعر الأصلي 💰',
        'واتساب':'هفتح ليك واتساب مع فريقنا دلوقتي 📞',
        'تواصل':'يسعدنا نتواصل معاك! هفتح واتساب 💬',
        'مرحبا':'أهلاً وسهلاً! ✨ أنا هنا أساعدك، إيه اللي تحتاجه؟',
        'اهلا':'أهلاً وسهلاً! ✨',
        'default':'سؤال كويس! 🌿 للإجابة الدقيقة، فريقنا متاح على واتساب دلوقتي وهيساعدك في ثوانٍ 👇',
      }
    },
    en:{
      greet:'Hello! 👋 I\'m the PUREFORM assistant. I can help you find the right product. What are you looking for?',
      quick:['Hair products 💆','Fat burning 🔥','Protein & Creatine 💪','Shipping & Prices 🚚','Contact our team 📞'],
      bot_name:'PUREFORM Assistant',status_txt:'Available now',input_ph:'Type your question…',
      wa_cta:'Chat with our team on WhatsApp 💬',
      responses:{
        'hair':'For hair care, the Be Strong Kit is perfect 💪 Shampoo + Conditioner + Mist — reduces hair loss and nourishes from roots. Check RZN Beauty! 🌿',
        'fat':'Burnmode Tablets is our top fat burner 🔥 Natural extracts that boost energy and burn fat simultaneously!',
        'burn':'Burnmode Tablets is our top fat burner 🔥',
        'protein':'ISO Pro Protein is ideal for muscle building 💪 Pair it with Corepulse Creatine for faster results!',
        'creatine':'Corepulse Creatine boosts your training power and accelerates results 💪',
        'shipping':'Shipping is 70 EGP across Egypt 🚚 International shipping available to 16+ countries!',
        'price':'Prices start from 399 EGP. Every product saves you money vs. the original price 💰',
        'whatsapp':'Opening WhatsApp with our team now 📞',
        'contact':'We\'d love to help! Opening WhatsApp 💬',
        'hello':'Hello! ✨ I\'m here to help, what do you need?',
        'hi':'Hello! ✨',
        'default':'Great question! 🌿 For a precise answer, our team is available on WhatsApp and will help you in seconds 👇',
      }
    },
    fr:{
      greet:'Bonjour ! 👋 Je suis l\'assistant PUREFORM. Je peux vous aider à trouver le bon produit. Que cherchez-vous ?',
      quick:['Cheveux 💆','Brûler les graisses 🔥','Protéine & Créatine 💪','Livraison & Prix 🚚','Contacter notre équipe 📞'],
      bot_name:'Assistant PUREFORM',status_txt:'Disponible',input_ph:'Posez votre question…',
      wa_cta:'Parler à notre équipe sur WhatsApp 💬',
      responses:{
        'cheveu':'Pour les cheveux, le Be Strong Kit est parfait 💪',
        'hair':'Pour les cheveux, le Be Strong Kit est parfait 💪',
        'graisse':'Burnmode Tablets est notre meilleur brûleur de graisses 🔥',
        'proteine':'ISO Pro Protein est idéal pour la musculation 💪',
        'livraison':'La livraison est de 70 EGP en Égypte 🚚',
        'prix':'Les prix commencent à 399 EGP 💰',
        'default':'Bonne question ! 🌿 Notre équipe est disponible sur WhatsApp et vous répondra en quelques secondes 👇',
      }
    }
  };
  function L(){return KB[document.documentElement.lang||'ar']||KB.ar;}

  function applyLangToChat(){
    var lc=L();
    var nameEl=document.getElementById('chat-bot-name');
    var statusEl=document.getElementById('chat-status-txt');
    var inputEl=document.getElementById('chat-input');
    if(nameEl)nameEl.textContent=lc.bot_name;
    if(statusEl)statusEl.textContent=lc.status_txt;
    if(inputEl)inputEl.placeholder=lc.input_ph;
  }

  function addMsg(text,who,callback){
    var msgs=document.getElementById('chat-msgs');
    if(!msgs)return;
    var div=document.createElement('div');
    div.className='chat-msg '+who;
    div.textContent=text;
    msgs.appendChild(div);
    msgs.scrollTop=msgs.scrollHeight;
    if(callback)callback();
  }

  function showTyping(cb){
    var msgs=document.getElementById('chat-msgs');
    if(!msgs)return;
    var typing=document.createElement('div');
    typing.className='chat-msg bot chat-typing';
    typing.id='chat-typing';
    typing.innerHTML='<span></span><span></span><span></span>';
    msgs.appendChild(typing);
    msgs.scrollTop=msgs.scrollHeight;
    setTimeout(function(){
      var t=document.getElementById('chat-typing');
      if(t)t.remove();
      cb();
    },900+Math.random()*500);
  }

  function botReply(userText){
    var lc=L();
    var lower=userText.toLowerCase();
    var reply=lc.responses.default;
    var toWA=false;
    for(var key in lc.responses){
      if(key!=='default'&&lower.indexOf(key)>=0){
        reply=lc.responses[key];
        if(key==='واتساب'||key==='تواصل'||key==='whatsapp'||key==='contact'){toWA=true;}
        break;
      }
    }
    showTyping(function(){
      addMsg(reply,'bot');
      /* after default reply, offer WA */
      if(!toWA){
        setTimeout(function(){
          showTyping(function(){
            addMsg(lc.wa_cta,'bot',function(){
              /* append clickable link */
              var msgs=document.getElementById('chat-msgs');
              if(!msgs)return;
              var link=document.createElement('a');
              link.href='https://wa.me/201286332777';
              link.target='_blank';
              link.style.cssText='display:inline-flex;align-items:center;gap:.35rem;margin-top:.25rem;background:linear-gradient(135deg,#25D366,#1db954);color:#fff;padding:.45rem .9rem;border-radius:20px;font-size:.75rem;font-weight:700;text-decoration:none;font-family:Tajawal,sans-serif;';
              link.innerHTML='<i class="fab fa-whatsapp"></i> WhatsApp';
              var wrap=document.createElement('div');
              wrap.style.cssText='align-self:flex-start;';
              wrap.appendChild(link);
              msgs.appendChild(wrap);
              msgs.scrollTop=msgs.scrollHeight;
            });
          });
        },800);
      } else {
        setTimeout(function(){window.open('https://wa.me/201286332777','_blank');},400);
      }
      renderQuickBtns();
    });
  }

  function renderQuickBtns(){
    var el=document.getElementById('chat-quick');
    if(!el)return;
    var lc=L();
    el.innerHTML=lc.quick.map(function(q){
      return '<button class="chat-quick-btn" onclick="window._chatQuick(\''+q.replace(/'/g,"\\'")+'\')">'+(q.length>18?q.slice(0,18)+'…':q)+'</button>';
    }).join('');
  }

  window._chatQuick=function(text){
    addMsg(text,'user');
    botReply(text);
    var el=document.getElementById('chat-quick');
    if(el)el.innerHTML='';
  };

  window.sendChatMsg=function(){
    var inp=document.getElementById('chat-input');
    if(!inp)return;
    var text=inp.value.trim();
    if(!text)return;
    inp.value='';
    addMsg(text,'user');
    botReply(text);
  };

  window.toggleChat=function(){
    open=!open;
    var win=document.getElementById('chat-window');
    var unread=document.getElementById('chat-unread');
    if(!win)return;
    win.classList.toggle('open',open);
    if(open){
      if(unread)unread.style.display='none';
      applyLangToChat();
      /* show greeting if first open */
      var msgs=document.getElementById('chat-msgs');
      if(msgs&&msgs.children.length===0){
        setTimeout(function(){
          showTyping(function(){
            addMsg(L().greet,'bot');
            renderQuickBtns();
          });
        },300);
      }
    }
  };

  /* init */
  setTimeout(function(){
    var unread=document.getElementById('chat-unread');
    if(unread)unread.style.display='flex';
  },8000);
  applyLangToChat();
})();

