
   WISHLIST SYSTEM
══════════════════════════════════════════════════════════════ */
(function(){
  var WL = [];
  function save(){try{localStorage.setItem('pf_wl',JSON.stringify(WL));}catch(e){}}
  function load(){try{var d=localStorage.getItem('pf_wl');if(d)WL=JSON.parse(d);}catch(e){}}
  load();

  var T = {
    ar:{title:'المفضلة',empty:'مفضلتك فارغة',emptyHint:'احفظ منتجاتك المفضلة هنا',moveCart:'أضف للسلة',items:function(n){return n+' منتج';}},
    en:{title:'Wishlist',empty:'Your wishlist is empty',emptyHint:'Save products you love here',moveCart:'Add to Cart',items:function(n){return n+' item'+(n>1?'s':'');}},
    fr:{title:'Favoris',empty:'Votre liste est vide',emptyHint:'Sauvegardez vos produits favoris',moveCart:'Ajouter au panier',items:function(n){return n+' article'+(n>1?'s':'');}},
  };
  function L(){return T[document.documentElement.lang||'ar']||T.ar;}

  function updateBadge(){
    var el=document.getElementById('wl-count');
    if(el){el.textContent=WL.length;el.classList.toggle('vis',WL.length>0);}
    /* sync heart buttons */
    WL.forEach(function(id){
      var btn=document.getElementById('wl-'+id);
      if(btn)btn.classList.add('wl-on');
    });
    /* clear buttons not in WL */
    document.querySelectorAll('.wl-btn').forEach(function(btn){
      var id=btn.id.replace('wl-','');
      if(WL.indexOf(id)<0)btn.classList.remove('wl-on');
    });
  }

  window.toggleWishlist=function(id){
    var idx=WL.indexOf(id);
    if(idx<0){WL.push(id);}else{WL.splice(idx,1);}
    save();updateBadge();
    var btn=document.getElementById('wl-'+id);
    if(btn){btn.classList.toggle('wl-on',WL.indexOf(id)>=0);}
    if(document.getElementById('wl-drawer').classList.contains('open'))renderWL();
  };

  function renderWL(){
    var list=document.getElementById('wl-items-list');
    var titleEl=document.getElementById('wl-title-txt');
    if(!list)return;
    var lc=L();
    if(titleEl)titleEl.textContent=lc.title;
    if(WL.length===0){
      list.innerHTML='<div class="wl-empty"><span class="wl-empty-ico">🤍</span><div>'+lc.empty+'</div><div style="font-size:.75rem;opacity:.65">'+lc.emptyHint+'</div></div>';
      return;
    }
    list.innerHTML=WL.map(function(id){
      var p=window.PRODUCTS&&window.PRODUCTS[id];
      if(!p)return'';
      var img=p.img?'<img src="'+p.img+'" alt="'+p.nm+'" loading="lazy">':'<span style="font-size:1.4rem">'+(p.em||'🌿')+'</span>';
      return '<div class="wl-card" onclick="go(\'product\',\''+id+'\');closeWishlist()">'
        +'<div class="wl-card-img">'+img+'</div>'
        +'<div class="wl-card-body">'
        +  '<div class="wl-card-nm">'+p.nm+'</div>'
        +  '<div class="wl-card-kit">'+(p.kit||'')+'</div>'
        +  '<div class="wl-card-pr">'+p.pr.toLocaleString()+' جنيه</div>'
        +'</div>'
        +'<div class="wl-card-right">'
        +  '<button class="wl-del" onclick="event.stopPropagation();window.toggleWishlist(\''+id+'\')"><i class="fas fa-times"></i></button>'
        +  '<button class="wl-move-cart" onclick="event.stopPropagation();addToCart(\''+id+'\')">'+lc.moveCart+'</button>'
        +'</div>'
        +'</div>';
    }).join('');
  }

  window.openWishlist=function(){
    renderWL();
    document.getElementById('wl-drawer').classList.add('open');
    document.getElementById('wl-overlay').classList.add('open');
    document.body.style.overflow='hidden';
  };
  window.closeWishlist=function(){
    document.getElementById('wl-drawer').classList.remove('open');
    document.getElementById('wl-overlay').classList.remove('open');
    document.body.style.overflow='';
  };

  /* sync buttons after page navigation */
  var _prevGo=window.go;
  window.go=function(page,id){
    _prevGo(page,id);
    setTimeout(updateBadge,200);
  };

  updateBadge();
})();

/* ══════════════════════════════════════════════════════════════