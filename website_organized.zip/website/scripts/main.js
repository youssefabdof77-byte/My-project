/* =============================================================
   PUREFORM — scripts/main.js
   Core application logic.

   LOAD ORDER (index.html):
     1. products/*/data.js       — product data (KITS, ELEVATE arrays)
     2. components/language-system.js
     3. components/reviews.js    — review UI functions
     4. scripts/main.js          — this file (app core)
     5. scripts/cart.js
     6. scripts/wishlist.js
     7. scripts/upsell.js
     8. scripts/chat.js
   ============================================================= */


/* ══════════ DATA ══════════ */
const KITS=[
 {key:'strong',label:'Be Strong',icon:'💪',tag:'عناية الشعر',color:'#1B4332',items:[
   {id:'b1',em:'',nm:'Be Strong Shampoo',pr:550,orig:619,best:false,badge:'',tags:['جوز الهند','الريحان','الشيكاكاي','جنزبيل هندي','فيتامين هـ'],benefits:['يقلل التساقط بشكل ملحوظ','لمعان طبيعي وصحي','يرطب فروة الرأس'],uses:['تغذية كاملة للشعر من الجذور للأطراف','يمنح لمعان طبيعي وصحي','يوفر ترطيب عميق لفروة الرأس','يقلل فقدان البروتين الطبيعي للشعر','يعزز قوة الشعر ويقلل التساقط','مناسب لكل أنواع الشعر'],img:'New folder/WhatsApp Image 2026-02-25 at 10.14.09 AM (2).jpeg',problems:['hair']},
   {id:'b2',em:'',nm:'Be Strong Conditioner',pr:550,orig:619,best:true,badge:'الأكثر طلباً',tags:['الصبار','زيت الأرجان','زبدة الشيا','الكرياتين','جوز الهند'],benefits:['يصلح التلف ويقوي الشعر','حماية من أشعة الشمس','يقلل التقصف ٩٠٪'],uses:['إصلاح التلف','تقوية الشعر','حماية من الشمس','تقليل التقصف والتكسر','تجديد فروة الرأس','علاج الشعر الجاف'],img:'New folder/WhatsApp Image 2026-02-25 at 10.13.55 AM.jpeg',problems:['hair']},
   {id:'b3',em:'',nm:'Be Strong Hair Mist',pr:499,orig:568,best:true,badge:'مميز',tags:['الصبار','الأرجان','جوز الهند','الكرياتين','زيت اللوز'],benefits:['ترطيب طوال اليوم','يمنع الجفاف والتكسر','يعزز اللمعان الطبيعي'],uses:['ترطيب طوال اليوم','حماية من التلف','الحفاظ على البروتين الطبيعي','منع الجفاف','تعزيز اللمعان','تقليل التكسر'],img:'New folder/WhatsApp Image 2026-03-02 at 3.05.24 PM.jpeg',problems:['hair']},
 ]},
 {key:'enzyme',label:'Enzyme Kit',icon:'🌸',tag:'عناية البشرة',color:'#4a1942',items:[
   {id:'e1',em:'',nm:'Bloushing Blossom Body Wash',pr:399,orig:468,best:false,badge:'',tags:['بابايا','أناناس','زبدة الشيا','عشب الليمون'],benefits:['يرطب ويجدد خلايا البشرة','يزيل الجلد الميت بلطف','يفتح آثار الشمس'],uses:['مكافحة الجفاف','ترطيب عميق','تجديد خلايا البشرة','إزالة الجلد الميت','تفتيح آثار الشمس','تنظيف لطيف دون تجفيف'],img:'New folder/WhatsApp Image 2026-02-25 at 10.14.09 AM (1).jpeg',problems:['skin']},
   {id:'e2',em:'',nm:'Splash Face Scrub',pr:499,orig:568,best:false,badge:'',tags:['بابايا','أناناس','قرفة','بندق','فيتامين هـ'],benefits:['تقشير لطيف وآمن','يزيل الرؤوس السوداء','يعزز إنتاج الكولاجين'],uses:['تقشير لطيف وآمن','تنظيف عميق للمسام','إزالة الرؤوس السوداء','علاج آثار حب الشباب','تعزيز إنتاج الكولاجين','تحسين ملمس البشرة'],img:'New folder/WhatsApp Image 2026-02-25 at 10.14.10 AM.jpeg',problems:['acne','skin']},
   {id:'e3',em:'',nm:'Splash Face Wash',pr:499,orig:568,best:false,badge:'',tags:['بابايا','زيت شجرة الشاي','الخوخ الهندي','فيتامين هـ'],benefits:['تنظيف عميق مضاد للبكتيريا','يوحد لون البشرة','نضارة فورية بعد الغسيل'],uses:['تنظيف عميق للبشرة','مضاد للبكتيريا','توحيد لون البشرة','تقليل الزيوت الضارة','معالجة أضرار الأشعة فوق البنفسجية','منح نضارة فورية'],img:'New folder/WhatsApp Image 2026-02-25 at 10.12.08 AM.jpeg',problems:['acne','skin']},
 ]},
 {key:'berries',label:'Berries Kit',icon:'🍓',tag:'توت وفراولة',color:'#7B1D45',items:[
   {id:'be1',em:'',nm:'Berry Go Round Body Wash',pr:399,orig:468,best:false,badge:'',tags:['توت بري','فراولة','جنزبيل','زبدة الشيا'],benefits:['ترطيب عميق وإشراقة','تفتيح طبيعي','يجدد الخلايا ويحسن اللون'],uses:['ترطيب عميق','تحسين مظهر الخطوط','تفتيح طبيعي','تجديد خلايا البشرة','تصحيح لون البشرة','منح إشراقة صحية'],img:'New folder/WhatsApp Image 2026-02-25 at 10.12.50 AM.jpeg',problems:['skin']},
 ]},
 {key:'splash',label:'Body Splashes',icon:'✨',tag:'بخاخات الجسم',color:'#3D2C1E',items:[
   {id:'s1',em:'',nm:'Wiseman Body Splash',pr:659,orig:728,best:true,badge:'الأقوى مبيعاً',tags:['خشب الصندل الهندي','بانثينول','فيتامين هـ'],benefits:['ترطيب عميق طويل الأمد','يعالج حب الشباب والحكة','يساعد في التئام الجروح'],uses:['ترطيب عميق','الوقاية من علامات الشيخوخة','علاج حب الشباب','علاج الحكة','علاج حروق الشمس','المساعدة في التئام الجروح','المساعدة في حالات الأكزيما','رائحة ثابتة ومنعشة'],img:'New folder/WhatsApp Image 2026-02-25 at 10.14.02 AM.jpeg',problems:['skin','acne']},
   {id:'s2',em:'',nm:'Blind Date Body Splash',pr:659,orig:728,best:false,badge:'',tags:['خشب الصندل الهندي','بانثينول','فيتامين هـ'],benefits:['انتعاش ورائحة تدوم ساعات','يرطب ويعالج التهيج','يقلل الجفاف'],uses:['ترطيب الجسم','إحساس انتعاش طويل','علاج التهيج','تقليل الجفاف','المساعدة في شفاء البشرة','رائحة جذابة تدوم طويلًا'],img:'New folder/WhatsApp Image 2026-02-25 at 10.14.10 AM (1).jpeg',problems:['skin']},
 ]},
 {key:'lotion',label:'Lotion & Gift',icon:'🎁',tag:'لوشن وهدايا',color:'#1B3A4B',items:[
   {id:'l1',em:'',nm:'Your Love Body Lotion',pr:599,orig:668,best:true,badge:'الأعلى تقييماً',tags:['اللافندر','جوز الهند','الزيتون','زبدة الشيا','فيتامين هـ'],benefits:['ترطيب يدوم 12+ ساعة','يقلل الترهلات والخطوط','حماية كاملة من UV'],uses:['ترطيب عميق','تقليل الترهلات','مضاد للفطريات والبكتيريا','حماية من الأشعة فوق البنفسجية','منح ملمس ناعم حريري','تحسين مرونة الجلد'],img:'New folder/WhatsApp Image 2026-02-25 at 10.13.37 AM.jpeg',problems:['skin']},
   {id:'pk1',em:'',nm:'Package Kit الكاملة',pr:1250,orig:1319,best:false,badge:'هدية مثالية',tags:['عينات جميع المنتجات','شنطة أنيقة'],benefits:['تجربة كاملة لجميع المنتجات','هدية مميزة ومفيدة','توفير أكبر في الأسعار'],uses:['مثالي للتجربة الكاملة','مناسب كهدية فاخرة','طريقة رائعة لاكتشاف جميع المنتجات'],img:'New folder/WhatsApp Image 2026-02-25 at 10.13.29 AM.jpeg',problems:['other','skin','hair','acne']},
 ]},
];
const ELEVATE=[
 {id:'el1',em:'',nm:'Burnmode Tablets',pr:1500,orig:1569,best:true,badge:'الأكثر مبيعاً',sub:'Fat Burner',color:'#7B1D1D',macros:[],tags:['تركيبة حرق متطورة'],benefits:['حرق الدهون العنيدة','يرفع الطاقة والتركيز','يحسن التمثيل الغذائي'],uses:['حرق الدهون','التحكم في الوزن','رفع مستوى الطاقة','تحسين الهضم','تسريع التمثيل الغذائي','مناسب للدهون العنيدة','دعم عملية التخسيس'],img:'New folder/WhatsApp Image 2026-02-25 at 10.13.32 AM.jpeg',problems:['fat']},
 {id:'el2',em:'',nm:'Corepulse Creatine',pr:1351,orig:1420,best:false,badge:'',sub:'Performance Booster',color:'#1a2d6e',macros:[],tags:['كرياتين نقي','امتصاص سريع'],benefits:['يزيد القوة والأداء','يسرّع التعافي','مثالي للنحيفين'],uses:['زيادة القوة العضلية','تحسين الأداء في التمرين','تسريع التعافي','دعم نمو العضلات','زيادة القدرة على التحمل','مثالي للنحيفين'],img:'New folder/WhatsApp Image 2026-02-25 at 10.14.08 AM.jpeg',problems:['thinness','energy']},
 {id:'el3',em:'',nm:'MaxBulk Gainer',pr:2470,orig:2539,best:false,badge:'للنحيفين',sub:'Mass Gainer',color:'#3D2A1A',macros:['77g بروتين','125g كارب','935 كالوري','52 سكوب'],tags:['نكهتين متاحتين','عالي السعرات'],benefits:['زيادة وزن فعالة وسريعة','يبني كتلة عضلية حقيقية','مثالي للنحيفين جداً'],uses:['زيادة الوزن','بناء كتلة عضلية','دعم النحيفين','رفع السعرات اليومية بسهولة','تحسين شكل الجسم العام'],img:'New folder/WhatsApp Image 2026-02-25 at 10.13.53 AM.jpeg',problems:['thinness']},
 {id:'el4',em:'',nm:'ISO Pro Protein',pr:1760,orig:1829,best:false,badge:'',sub:'Whey Isolate',color:'#1B3A4B',macros:['بروتين نقي','بدون دهون','2 نكهة'],tags:['نكهتين','امتصاص فائق السرعة','صفر دهون'],benefits:['أنقى بروتين في السوق','يحفظ العضلة أثناء التخسيس','تعافي أسرع بعد التمرين'],uses:['تناول بعد التمرين','الحفاظ على العضلات أثناء التخسيس','تسريع التعافي','تقليل فقدان الكتلة العضلية','دعم نظام غذائي صحي'],img:'New folder/WhatsApp Image 2026-02-25 at 10.14.09 AM.jpeg',problems:['fat','thinness','energy']},
];
const REVIEWS={
 b1:[{n:'سارة محمد',s:5,t:'من أحسن شامبو جربته، شعري بقى أقوى وأكثر لمعاناً بعد أسبوعين بس!',d:'منذ أسبوع'},{n:'منة الله عصام',s:5,t:'التساقط وقف تقريباً، حاسة بفرق كبير من أول استخدام.',d:'منذ أسبوعين'},{n:'نورهان أحمد',s:5,t:'الريحة حلوة جداً والشعر بقى ناعم وصحي.',d:'منذ ٣ أسابيع'},{n:'رنا إبراهيم',s:4,t:'منتج طبيعي ومكوناته واضحة، حاسة بفرق في القوة.',d:'منذ شهر'},{n:'ياسمين علي',s:5,t:'أكثر شامبو استخدمته مرتين في الأسبوع وشعري صحح بالكامل.',d:'منذ شهر'},{n:'دينا محمود',s:5,t:'اشتريته بناء على توصية صاحبتي وما خذلتنيش.',d:'منذ شهر'},{n:'شروق أحمد',s:5,t:'البروتين الطبيعي اللي فيه حافظ على شعري من التلف.',d:'منذ شهرين'},{n:'هدير سامي',s:4,t:'كنت بيتساقط شعري كتير وبعد استخدامه قل جداً.',d:'منذ شهرين'},{n:'غادة يوسف',s:5,t:'شعري الجاف بقى حي ومبلل طول اليوم.',d:'منذ شهرين'},{n:'إيمان طارق',s:5,t:'أنصح بيه لأي حد عنده مشكلة تساقط.',d:'منذ ٣ شهور'},{n:'مها فريد',s:5,t:'حتى ريحته طبيعية ومش مصنعة.',d:'منذ ٣ شهور'},{n:'نجوى سالم',s:4,t:'الاختلاف واضح في ملمس الشعر من أول شهر.',d:'منذ ٤ شهور'},{n:'لمياء حسن',s:5,t:'الكيت كاملة مع المكيف تجربة استثنائية.',d:'منذ ٤ شهور'},{n:'أسماء كريم',s:5,t:'بستخدمه لأكتر من ٤ شهور وما خذلنيش.',d:'منذ ٥ شهور'},{n:'زينب محسن',s:5,t:'أحسن استثمار في الشعر عملته في حياتي.',d:'منذ ٥ شهور'}],
 b2:[{n:'نهال سامي',s:5,t:'مكيف رهيب، من بعده شعري بقى ناعم جداً وما فيش تقصف خالص.',d:'منذ أسبوع'},{n:'مريم طارق',s:5,t:'الكرياتين فيه حاجة سحرية، الشعر بقى كثيف.',d:'منذ أسبوعين'},{n:'ريهام أحمد',s:5,t:'أحسن مكيف جربته، ما بيثقلش الشعر وبيرطبه بشكل حقيقي.',d:'منذ ٣ أسابيع'},{n:'ولاء محمد',s:4,t:'الزبدة الشيا والأرجان بيديوا ترطيب ممتاز.',d:'منذ شهر'},{n:'سلمى خالد',s:5,t:'من بعد استخدامه شعري بقى يتمشط بسهولة.',d:'منذ شهر'},{n:'أميرة سيد',s:5,t:'التقصف راح تماماً بعد أسبوعين.',d:'منذ شهر'},{n:'هناء عمر',s:5,t:'أحسن مكيف في السوق بكل صراحة.',d:'منذ شهرين'},{n:'نادية يوسف',s:5,t:'الشعر الجاف تعافى بشكل ملحوظ.',d:'منذ شهرين'},{n:'إيناس محمود',s:4,t:'رائحته حلوة وبيدي شعر كالحرير.',d:'منذ شهرين'},{n:'شيماء حسن',s:5,t:'بستخدمه مع الشامبو والنتيجة ممتازة جداً.',d:'منذ ٣ شهور'},{n:'فريدة سالم',s:5,t:'حتى الشعر المحروق من الحرارة تحسن كتير.',d:'منذ ٣ شهور'},{n:'نسرين فتحي',s:5,t:'من أفضل ما جربته للشعر المجعد.',d:'منذ ٤ شهور'},{n:'إيمان عصام',s:5,t:'يستحق كل قرش، النتيجة تتكلم عن نفسها.',d:'منذ ٤ شهور'},{n:'مهند علي',s:4,t:'جربته لزوجتي وانبسطت جداً.',d:'منذ ٥ شهور'},{n:'وفاء إبراهيم',s:5,t:'الشعر بقى أجمل وأحسن بعد الاستخدام المستمر.',d:'منذ ٦ شهور'}],
 b3:[{n:'أميرة كريم',s:5,t:'أفضل مست للشعر، بطبقه على الشعر المبلول والنتيجة جنان.',d:'منذ أسبوع'},{n:'لمياء حسن',s:5,t:'ترطيب طول اليوم بدون أي ثقل على الشعر.',d:'منذ أسبوعين'},{n:'ريم سيد',s:5,t:'بقيت بستخدمه يومياً وشعري ما بيتكسرش خالص.',d:'منذ شهر'},{n:'سمر نبيل',s:4,t:'الرائحة حلوة والحماية من الحرارة واضحة.',d:'منذ شهر'},{n:'دعاء سمير',s:5,t:'أنقذ شعري من الجفاف الشديد.',d:'منذ شهرين'},{n:'هبة محمد',s:5,t:'بستخدمه قبل الفرد وبيحمي شعري من الحرارة.',d:'منذ شهرين'},{n:'رهف أحمد',s:5,t:'الكرياتين فيه بيقوي الشعر من الداخل.',d:'منذ ٣ شهور'},{n:'سوسن علي',s:4,t:'سعر كويس جداً مقارنة بالنتيجة.',d:'منذ ٣ شهور'},{n:'وسام طارق',s:5,t:'شعري المصبوغ بقى أحسن بكتير.',d:'منذ ٤ شهور'},{n:'إيمان عمرو',s:5,t:'من أحسن منتجات العناية بالشعر.',d:'منذ ٤ شهور'},{n:'فاطمة خليل',s:5,t:'بعد الاستحمام مباشرة بطبقه وشعري بيبقى ناعم جداً.',d:'منذ ٥ شهور'},{n:'منال محمود',s:5,t:'الجفاف راح والشعر بقى يتنفس.',d:'منذ ٥ شهور'},{n:'مرام حسن',s:4,t:'أنصح بيه كل بنت عندها مشكلة جفاف.',d:'منذ ٦ شهور'},{n:'شرين فتحي',s:5,t:'بيعمل فرق ملحوظ من أول أسبوع.',d:'منذ ٦ شهور'},{n:'نور الهدى',s:5,t:'منتج جبار بسعر معقول.',d:'منذ ٧ شهور'}],
 e1:[{n:'نجوى فاروق',s:5,t:'بشرتي بقت ناعمة ومضيئة من أول أسبوع، جنان.',d:'منذ أسبوع'},{n:'شروق محمد',s:5,t:'رائحة البابايا رائعة والترطيب ممتاز وطويل الأمد.',d:'منذ أسبوعين'},{n:'هبة عمر',s:5,t:'الجلد الميت راح تماماً وبشرتي بقت زي الحرير.',d:'منذ شهر'},{n:'نادية أحمد',s:4,t:'ترطيب رائع ورائحة منعشة جداً.',d:'منذ شهر'},{n:'سلوى إبراهيم',s:5,t:'بعد الاستحمام بيه بشرتي بتكون ناعمة وأبيض.',d:'منذ شهرين'},{n:'إلهام سامي',s:5,t:'أحسن غسيل جسم جربته في حياتي.',d:'منذ شهرين'},{n:'هند يوسف',s:5,t:'الأناناس والبابايا بيعملوا تقشير طبيعي خفيف.',d:'منذ ٣ شهور'},{n:'نهى محمد',s:4,t:'آمن على البشرة الحساسة.',d:'منذ ٣ شهور'},{n:'رانيا عصام',s:5,t:'بقى جزء أساسي في روتين حمامي.',d:'منذ ٤ شهور'},{n:'سمية حسن',s:5,t:'آثار الشمس بدأت تخف بشكل ملحوظ.',d:'منذ ٤ شهور'},{n:'مها سالم',s:5,t:'يستحق كل توصية، بشرتي تغيرت للأحسن.',d:'منذ ٥ شهور'},{n:'شيرين علي',s:4,t:'النتيجة تتكلم عن نفسها.',d:'منذ ٥ شهور'},{n:'أسمى فريد',s:5,t:'عبيه بيكمل تجربة الاستحمام بشكل رائع.',d:'منذ ٦ شهور'},{n:'نيفين طارق',s:5,t:'أنصح كل بنت تجربه.',d:'منذ ٦ شهور'},{n:'هاله محمود',s:5,t:'مكوناته طبيعية وآمنة وبتشتغل بشكل ممتاز.',d:'منذ ٧ شهور'}],
 e2:[{n:'ياسمين عبدالله',s:5,t:'الرؤوس السوداء اختفت بعد أسبوعين بس، صدمة إيجابية.',d:'منذ أسبوع'},{n:'إيناس سمير',s:5,t:'تقشير خفيف ومريح ومش عنيف على البشرة.',d:'منذ أسبوعين'},{n:'سلمى خالد',s:5,t:'بستخدمه مرتين في الأسبوع والفرق واضح جداً.',d:'منذ شهر'},{n:'نهال إبراهيم',s:4,t:'رائحة البابايا والقرفة مع بعض حلوة جداً.',d:'منذ شهر'},{n:'نورا محمد',s:5,t:'بشرتي بقت أنعم بكتير وأقل إرهاقاً.',d:'منذ شهرين'},{n:'شهد أحمد',s:5,t:'بعد الاستخدام بيه وجهي بيكون مضيء.',d:'منذ شهرين'},{n:'رنا علي',s:5,t:'حتى الكولاجين بدأ يزيد والبشرة بقت ممتلئة.',d:'منذ ٣ شهور'},{n:'ليلى حسن',s:4,t:'آمن وفعّال ومنتج استثنائي بسعر ممتاز.',d:'منذ ٣ شهور'},{n:'هناء سالم',s:5,t:'من أفضل مقشرات الوجه اللي جربتها.',d:'منذ ٤ شهور'},{n:'نفيسة يوسف',s:5,t:'الحبوب والبقع بدأت تختفي من الأسبوع الأول.',d:'منذ ٤ شهور'},{n:'وسام إسماعيل',s:5,t:'مناسب حتى للبشرة الحساسة.',d:'منذ ٥ شهور'},{n:'سارة خليل',s:5,t:'أنصح بيه لكل بنت عندها مشكلة حب شباب.',d:'منذ ٥ شهور'},{n:'إيمان عمر',s:4,t:'ممتاز ومكوناته طبيعية وآمنة.',d:'منذ ٦ شهور'},{n:'منى فتحي',s:5,t:'فرق حقيقي في ملمس البشرة.',d:'منذ ٦ شهور'},{n:'دعاء محمود',s:5,t:'بقى ثابت في روتيني الأسبوعي.',d:'منذ ٧ شهور'}],
 e3:[{n:'مها إبراهيم',s:5,t:'أحسن غسيل وجه جربته، بيعمل تنظيف عميق وبدون تجفيف.',d:'منذ أسبوع'},{n:'دعاء أحمد',s:5,t:'حب الشباب قل بشكل ملحوظ من الأسبوع الثاني.',d:'منذ أسبوعين'},{n:'ولاء عصام',s:5,t:'وجهي مشرق بعد الاستخدام مباشرة.',d:'منذ شهر'},{n:'هدى محمد',s:4,t:'زيت شجرة الشاي بيعمل فرق في البثور.',d:'منذ شهر'},{n:'سناء أحمد',s:5,t:'بيغسل الوجه بعمق من غير ما يجففه.',d:'منذ شهرين'},{n:'نيرة حسن',s:5,t:'توحيد لون البشرة محسوس بعد شهر استخدام.',d:'منذ شهرين'},{n:'مرفت سامي',s:5,t:'للبشرة الدهنية ده الأنسب بدون منازع.',d:'منذ ٣ شهور'},{n:'وفاء خليل',s:4,t:'آمن ومناسب للاستخدام اليومي.',d:'منذ ٣ شهور'},{n:'إيمان عادل',s:5,t:'الجلد بعده بيكون نضيف ومضيء.',d:'منذ ٤ شهور'},{n:'نجلاء يوسف',s:5,t:'يستحق كل توصية، نتيجة رائعة.',d:'منذ ٤ شهور'},{n:'رشا سيد',s:5,t:'غيرت شكل بشرتي للأحسن.',d:'منذ ٥ شهور'},{n:'أسماء كريم',s:4,t:'رائحته منعشة ومريحة جداً.',d:'منذ ٥ شهور'},{n:'مي فريد',s:5,t:'بقى جزء من روتين صباحي اليومي.',d:'منذ ٦ شهور'},{n:'شيرين أحمد',s:5,t:'أقل منتج بنفس الجودة في السوق.',d:'منذ ٦ شهور'},{n:'منار إبراهيم',s:5,t:'أنصح بيه لكل صاحبة معندهاش تجربة في العناية.',d:'منذ ٧ شهور'}],
 be1:[{n:'أسماء طارق',s:5,t:'رائحة الفراولة زكية جداً والترطيب ممتاز وطويل.',d:'منذ أسبوع'},{n:'زينب علي',s:5,t:'بشرتي بقت أفتح وأكثر إشراقاً من بعد أسبوع.',d:'منذ أسبوعين'},{n:'شيماء حسين',s:4,t:'منتج رائع وسعره كويس مقارنة بالجودة.',d:'منذ شهر'},{n:'ريهام سعيد',s:5,t:'الجنزبيل فيه بيدفئ البشرة ويفتحها.',d:'منذ شهر'},{n:'دينا يوسف',s:5,t:'الخطوط بدأت تخف بعد شهر استخدام.',d:'منذ شهرين'},{n:'سلمى محمد',s:5,t:'التجديد اللي بيعمله للخلايا محسوس.',d:'منذ شهرين'},{n:'نهاد إبراهيم',s:4,t:'ترطيب ممتاز خاصة في الشتاء.',d:'منذ ٣ شهور'},{n:'هبة طارق',s:5,t:'من أحسن غسيل جسم جربته.',d:'منذ ٣ شهور'},{n:'رانيا عمر',s:5,t:'اللون بقى أوحد وأحسن.',d:'منذ ٤ شهور'},{n:'ريم فتحي',s:5,t:'ممتاز للبشرة الجافة.',d:'منذ ٤ شهور'},{n:'إيمان حسن',s:5,t:'بستخدمه بعد الاستحمام وبشرتي حريرية.',d:'منذ ٥ شهور'},{n:'نيفين خليل',s:4,t:'رائحته فاكهة وحلوة جداً.',d:'منذ ٥ شهور'},{n:'هناء سالم',s:5,t:'آمن وطبيعي ومفيش أي تحسس.',d:'منذ ٦ شهور'},{n:'شيرين يوسف',s:5,t:'النتيجة تتكلم عن نفسها.',d:'منذ ٦ شهور'},{n:'منال أحمد',s:5,t:'يستحق كل توصية.',d:'منذ ٧ شهور'}],
 s1:[{n:'أحمد خالد',s:5,t:'الرائحة بتيجي عليك طول اليوم، ومبلل بشكل ممتاز.',d:'منذ أسبوع'},{n:'كريم علي',s:5,t:'حل مشكلة حب الشباب على الظهر تماماً بعد شهر.',d:'منذ أسبوعين'},{n:'محمد سامي',s:5,t:'أحسن بديل عن كل الـ body sprays التجارية.',d:'منذ شهر'},{n:'عمر إبراهيم',s:5,t:'استخدمته لما كنت بعاني من الحكة وحل المشكلة.',d:'منذ شهر'},{n:'ياسر محمود',s:4,t:'الصندل الهندي بيدي رائحة راقية ومميزة.',d:'منذ شهرين'},{n:'مصطفى عادل',s:5,t:'بشرتي بقت أنعم وأصح.',d:'منذ شهرين'},{n:'إيهاب فوزي',s:5,t:'الأكزيما اللي كانت عندي خفت كتير.',d:'منذ ٣ شهور'},{n:'هاني سعد',s:4,t:'طبيعي ومفيش مواد كيميائية.',d:'منذ ٣ شهور'},{n:'وليد حسن',s:5,t:'الترطيب بيدوم ليومين كاملين.',d:'منذ ٤ شهور'},{n:'طارق نبيل',s:5,t:'من أحسن منتجات العناية بالجسم.',d:'منذ ٤ شهور'},{n:'رامي صادق',s:5,t:'حروق الشمس اللي كانت عندي اتحسنت.',d:'منذ ٥ شهور'},{n:'سيد رضا',s:4,t:'ممتاز للبشرة الجافة والحساسة.',d:'منذ ٥ شهور'},{n:'شادي عمر',s:5,t:'يستحق كل جنيه.',d:'منذ ٦ شهور'},{n:'زياد أحمد',s:5,t:'بنصح كل رجل يجربه.',d:'منذ ٦ شهور'},{n:'نبيل فريد',s:5,t:'من أحسن مشترياتي.',d:'منذ ٧ شهور'}],
 s2:[{n:'فاطمة حسن',s:5,t:'الرائحة أنثوية ورائعة وبتدوم لساعات طويلة.',d:'منذ أسبوع'},{n:'ريهام أحمد',s:5,t:'الانتعاش اللي بيديه مختلف عن أي منتج تاني.',d:'منذ أسبوعين'},{n:'أسماء إبراهيم',s:5,t:'بشرتي بقت أنعم وأكثر ترطيباً.',d:'منذ شهر'},{n:'نجلاء محمد',s:4,t:'رائحة الصندل الهندي رائعة جداً.',d:'منذ شهر'},{n:'هبة طارق',s:5,t:'التهيج اللي كان عندي راح.',d:'منذ شهرين'},{n:'إيمان سامي',s:5,t:'مناسب للاستخدام اليومي.',d:'منذ شهرين'},{n:'سمر خالد',s:5,t:'ترطيب عميق ورائحة تدوم.',d:'منذ ٣ شهور'},{n:'رانيا عمر',s:4,t:'آمن وطبيعي.',d:'منذ ٣ شهور'},{n:'شيرين يوسف',s:5,t:'شفاء البشرة محسوس من الأسبوع الأول.',d:'منذ ٤ شهور'},{n:'ليلى حسن',s:5,t:'بقى ثابت في روتيني اليومي.',d:'منذ ٤ شهور'},{n:'دعاء فتحي',s:5,t:'يستحق التجربة والتوصية.',d:'منذ ٥ شهور'},{n:'منى سيد',s:5,t:'أنصح بيه لكل بنت.',d:'منذ ٥ شهور'},{n:'هدى علي',s:4,t:'ممتاز وسعر معقول.',d:'منذ ٦ شهور'},{n:'نهال سالم',s:5,t:'رائحته تبقى معاك طول اليوم.',d:'منذ ٦ شهور'},{n:'إيناس طارق',s:5,t:'تجربة ممتعة ومريحة.',d:'منذ ٧ شهور'}],
 l1:[{n:'ناهد إسماعيل',s:5,t:'أحسن لوشن جربته، بيدي نعومة من أول مرة وبيدوم طول اليوم.',d:'منذ أسبوع'},{n:'سوسن مجدي',s:5,t:'الترطيب بيدوم لأكثر من 12 ساعة، ما عاد عندي جفاف.',d:'منذ أسبوعين'},{n:'نانسي عادل',s:5,t:'رائحة اللافندر بتريحك نفسياً وبيلين الجلد.',d:'منذ شهر'},{n:'وفاء سليم',s:5,t:'بستخدمه بعد الاستحمام مباشرة والفرق واضح على الجلد.',d:'منذ شهر'},{n:'هبة رمزي',s:4,t:'الترهلات بدأت تقل بعد شهرين استخدام.',d:'منذ شهرين'},{n:'إيمان صادق',s:5,t:'مضاد الفطريات شغلته واضحة.',d:'منذ شهرين'},{n:'ريهام الشاذلي',s:5,t:'من أفضل لوشنات الجسم في السوق.',d:'منذ ٣ شهور'},{n:'سلمى فهمي',s:5,t:'الزبدة الشيا فيه بتعمل فرق حقيقي.',d:'منذ ٣ شهور'},{n:'مها صلاح',s:4,t:'آمن للبشرة الحساسة والجافة.',d:'منذ ٤ شهور'},{n:'دينا فتحي',s:5,t:'الجلد بقى مرن ونضر.',d:'منذ ٤ شهور'},{n:'شيرين حسن',s:5,t:'بيحمي من الأشعة فوق البنفسجية.',d:'منذ ٥ شهور'},{n:'هناء يوسف',s:5,t:'يستحق كل جنيه.',d:'منذ ٥ شهور'},{n:'نهال محمد',s:5,t:'من أكثر منتجات العناية تأثيراً.',d:'منذ ٦ شهور'},{n:'نجلاء طارق',s:4,t:'رائحة لطيفة ومريحة وترطيب استثنائي.',d:'منذ ٦ شهور'},{n:'رنا سالم',s:5,t:'أنصح بيه لكل بنت.',d:'منذ ٧ شهور'}],
 pk1:[{n:'هدير محمد',s:5,t:'هدية مثالية لأمي وانبسطت جداً بكل المنتجات.',d:'منذ أسبوعين'},{n:'غادة يوسف',s:5,t:'جربت كل المنتجات وكلها تمام على بعض.',d:'منذ شهر'},{n:'إيمان خليل',s:5,t:'الشنطة أنيقة جداً ومناسب جداً كهدية فاخرة.',d:'منذ شهر'},{n:'ريم فتحي',s:4,t:'توفير ممتاز مقارنة بشراء كل منتج لوحده.',d:'منذ شهرين'},{n:'نادية حسن',s:5,t:'أهديته لصاحبتي وانبسطت جداً وعايزة تعيد تجربته.',d:'منذ شهرين'},{n:'سمر عمر',s:5,t:'الكيت كاملة شاملة لكل احتياجات العناية.',d:'منذ ٣ شهور'},{n:'شيرين أحمد',s:4,t:'تجربة رائعة لمعرفة كل المنتجات.',d:'منذ ٣ شهور'},{n:'منال محمود',s:5,t:'هدية مميزة لأي مناسبة.',d:'منذ ٤ شهور'},{n:'لمياء يوسف',s:5,t:'المنتجات مترتبة وجميلة في الشنطة.',d:'منذ ٤ شهور'},{n:'هبة سالم',s:5,t:'اشتريته لخطيبتي وانبسطت كتير.',d:'منذ ٥ شهور'},{n:'دعاء طارق',s:5,t:'يستحق السعر ألف مرة.',d:'منذ ٥ شهور'},{n:'نجلاء إبراهيم',s:4,t:'تغليف أنيق ومحكم.',d:'منذ ٦ شهور'},{n:'مرفت خليل',s:5,t:'أنصح بيه كهدية في كل مناسبة.',d:'منذ ٦ شهور'},{n:'رانيا سيد',s:5,t:'بتبعث وجه مضيء وهدية مفيدة.',d:'منذ ٧ شهور'},{n:'هدى فتحي',s:5,t:'من أجمل هدايا ممكن تتقدمها.',d:'منذ ٧ شهور'}],
 el1:[{n:'باسم عصفور',s:5,t:'نزلت 9 كيلو في شهر ونص مع الكارديو، شغال بجد صح!',d:'منذ أسبوع'},{n:'رامي حسن',s:5,t:'الطاقة اتحسنت كتير جداً وحرق الدهون واضح.',d:'منذ أسبوعين'},{n:'كريم عادل',s:5,t:'الدهون العنيدة في البطن بدأت تختفي بعد 3 أسابيع.',d:'منذ شهر'},{n:'طارق نبيل',s:5,t:'بصراحة من أحسن المنتجات اللي جربتها في التخسيس.',d:'منذ شهر'},{n:'وليد سمير',s:5,t:'مع الريجيم اشتغل ممتاز جداً وما في أي آثار جانبية.',d:'منذ شهرين'},{n:'أشرف مجدي',s:4,t:'حرق الدهون محسوس من الأسبوع الثاني.',d:'منذ شهرين'},{n:'محسن طارق',s:5,t:'الهضم تحسن بشكل ملحوظ.',d:'منذ ٣ شهور'},{n:'ياسر إبراهيم',s:5,t:'للدهون العنيدة ده الحل.',d:'منذ ٣ شهور'},{n:'فارس علي',s:4,t:'بيعطي طاقة كافية للكارديو.',d:'منذ ٤ شهور'},{n:'صلاح فهمي',s:5,t:'التمثيل الغذائي اتسرع بشكل ملحوظ.',d:'منذ ٤ شهور'},{n:'أيمن رشاد',s:5,t:'نزلت 15 كيلو في ثلاثة شهور.',d:'منذ ٥ شهور'},{n:'عمر الشيخ',s:4,t:'نتيجة حقيقية وملموسة.',d:'منذ ٥ شهور'},{n:'حسام عزيز',s:5,t:'أنصح بيه كل شخص عنده مشكلة في الدهون.',d:'منذ ٦ شهور'},{n:'زياد محمود',s:5,t:'بيشتغل حتى بدون حمية صارمة.',d:'منذ ٦ شهور'},{n:'خالد صلاح',s:5,t:'من أفضل منتجات حرق الدهون الطبيعية.',d:'منذ ٧ شهور'}],
 el2:[{n:'عمرو الشرقاوي',s:5,t:'القوة زادت بشكل ملحوظ من أول أسبوعين، حاسس بفرق حقيقي.',d:'منذ أسبوع'},{n:'مصطفى أحمد',s:5,t:'التعافي بين التمارين بقى أسرع بكتير.',d:'منذ أسبوعين'},{n:'إسلام علي',s:5,t:'أحسن كرياتين جربته، النتيجة واضحة على الأداء.',d:'منذ شهر'},{n:'يوسف محمد',s:5,t:'زدت 4 كيلو في شهر مع التمرين المنتظم.',d:'منذ شهر'},{n:'حمزة عصفور',s:4,t:'القدرة على التحمل زادت بشكل ملحوظ.',d:'منذ شهرين'},{n:'فادي سالم',s:5,t:'من أفضل الكرياتين في السوق.',d:'منذ شهرين'},{n:'كريم طارق',s:5,t:'بيذوب في الماء بسهولة وما بيسبب أي مشاكل.',d:'منذ ٣ شهور'},{n:'علاء يحيى',s:4,t:'شغال 100% مع التمارين الثقيلة.',d:'منذ ٣ شهور'},{n:'نضال صادق',s:5,t:'نمو العضلات واضح بعد شهرين.',d:'منذ ٤ شهور'},{n:'سليم رزق',s:5,t:'للنحيفين ده الاختيار الأمثل.',d:'منذ ٤ شهور'},{n:'فيصل عمر',s:4,t:'امتصاصه سريع وبيشتغل بكفاءة.',d:'منذ ٥ شهور'},{n:'محمود نجيب',s:5,t:'زيادة الكتلة العضلية محسوسة.',d:'منذ ٥ شهور'},{n:'خلدون رفيق',s:5,t:'أنصح بيه لكل نحيف.',d:'منذ ٦ شهور'},{n:'هيثم فاروق',s:5,t:'تحسن الأداء واضح من الأسبوع الأول.',d:'منذ ٦ شهور'},{n:'وسيم علي',s:5,t:'من أفضل مشترياتي للتمرين.',d:'منذ ٧ شهور'}],
 el3:[{n:'أحمد النجار',s:5,t:'أخيراً وجدت حلاً حقيقياً للنحافة، زدت 6 كيلو في شهرين!',d:'منذ أسبوعين'},{n:'محمد الصواف',s:5,t:'النكهتين تمام والخلطة ليها ما بعدها.',d:'منذ شهر'},{n:'حامد إبراهيم',s:5,t:'سعرات عالية وبروتين كافي، مثالي للنحيفين.',d:'منذ شهر'},{n:'رضا علاء',s:5,t:'بستخدمه بعد التمرين مباشرة والفرق واضح.',d:'منذ شهرين'},{n:'صلاح عزيز',s:4,t:'المقدار الواحد بيديك كمية كبيرة من السعرات.',d:'منذ شهرين'},{n:'ماجد حسين',s:5,t:'زدت 3 كيلو في أول شهر.',d:'منذ ٣ شهور'},{n:'سامر فريد',s:5,t:'بيتخلط كويس وما بيعمل نفاخة.',d:'منذ ٣ شهور'},{n:'طارق راغب',s:4,t:'52 سكوب بسعر معقول جداً.',d:'منذ ٤ شهور'},{n:'خالد عيد',s:5,t:'من أفضل الـ gainers في السوق.',d:'منذ ٤ شهور'},{n:'فتحي جمال',s:5,t:'بناء الكتلة العضلية واضح.',d:'منذ ٥ شهور'},{n:'ياسين عمر',s:4,t:'طعمه كويس ومرضيش أي آثار جانبية.',d:'منذ ٥ شهور'},{n:'منير عبدالله',s:5,t:'زيادة الوزن جاءت بشكل صحي.',d:'منذ ٦ شهور'},{n:'تيسير محمد',s:5,t:'أنصح بيه لكل نحيف يريد أن يزيد.',d:'منذ ٦ شهور'},{n:'بسام طارق',s:5,t:'النتيجة فاقت توقعاتي.',d:'منذ ٧ شهور'},{n:'عبدالله فهد',s:5,t:'من أحسن مشترياتي في رحلة التضخيم.',d:'منذ ٧ شهور'}],
 el4:[{n:'ماجد سالم',s:5,t:'أحسن بروتين للتخسيس، حافظت على عضلاتي وأنا بنزل.',d:'منذ أسبوع'},{n:'نادر عزيز',s:5,t:'بدون دهون ومذاقه ممتاز، بستخدمه يومياً بعد التمرين.',d:'منذ أسبوعين'},{n:'أيمن فتحي',s:5,t:'التعافي بعد التمرين أسرع بكتير منذ بدأت فيه.',d:'منذ شهر'},{n:'تامر حسام',s:5,t:'جودة ممتازة وسعر معقول مقارنة بالسوق.',d:'منذ شهر'},{n:'ضياء عمر',s:4,t:'الامتصاص السريع محسوس.',d:'منذ شهرين'},{n:'رشيد علي',s:5,t:'النكهتين لذيذتين وما فيش بعد الطعم.',d:'منذ شهرين'},{n:'حسن محمود',s:5,t:'من أنقى البروتينات في السوق.',d:'منذ ٣ شهور'},{n:'عادل رضا',s:4,t:'يذوب بسهولة في الماء واللبن.',d:'منذ ٣ شهور'},{n:'فراس خليل',s:5,t:'الكتلة العضلية محفوظة حتى في فترة التقطيع.',d:'منذ ٤ شهور'},{n:'وسيم يحيى',s:5,t:'أنصح بيه لكل متمرن يريد نتائج حقيقية.',d:'منذ ٤ شهور'},{n:'أسامة صادق',s:5,t:'من أفضل الـ isolates بالسعر ده.',d:'منذ ٥ شهور'},{n:'ليث عمران',s:4,t:'الصفر دهون محسوس في التكوين الجسدي.',d:'منذ ٥ شهور'},{n:'حيدر فاروق',s:5,t:'بيساعد في الحمية والتحكم في الوزن.',d:'منذ ٦ شهور'},{n:'كمال طارق',s:5,t:'النتيجة فعلية ومحسوسة.',d:'منذ ٦ شهور'},{n:'عمار ياسين',s:5,t:'من أحسن مشترياتي في العام ده.',d:'منذ ٧ شهور'}],
};

const PRODUCTS={};
KITS.forEach(k=>k.items.forEach(p=>PRODUCTS[p.id]={...p,kit:k.label}));
ELEVATE.forEach(p=>PRODUCTS[p.id]={...p,kit:'Elevate'});
window.PRODUCTS=PRODUCTS; /* expose for cart IIFE */
const CARD_GRADS={b1:'linear-gradient(135deg,#1B4332,#2D6A4F)',b2:'linear-gradient(135deg,#155235,#38826A)',b3:'linear-gradient(135deg,#1D5C40,#47A374)',e1:'linear-gradient(135deg,#4A1942,#7B3472)',e2:'linear-gradient(135deg,#5C1A4A,#8B4060)',e3:'linear-gradient(135deg,#3A2060,#6A4A9A)',be1:'linear-gradient(135deg,#7B1D45,#B84070)',s1:'linear-gradient(135deg,#3D2C1E,#7A5535)',s2:'linear-gradient(135deg,#4A2A28,#8A4A45)',l1:'linear-gradient(135deg,#1B3A4B,#3A7A9A)',pk1:'linear-gradient(135deg,#3D1E5A,#7A3A9A)',el1:'linear-gradient(135deg,#7B1D1D,#C0392B)',el2:'linear-gradient(135deg,#1a2d6e,#3A5ABE)',el3:'linear-gradient(135deg,#3D2A1A,#7A5030)',el4:'linear-gradient(135deg,#1B3A4B,#3A7080)'};

/* ══════════ STATE ══════════ */
let USER=null;


/* ══════════ COUNTRIES & LANGUAGE ══════════ */
const COUNTRIES=[
  /* ── Arab World ── */
  {f:'🇪🇬',n:{ar:'مصر',en:'Egypt',fr:'Égypte'},        lang:'ar',group:'arab'},
  {f:'🇸🇦',n:{ar:'السعودية',en:'Saudi Arabia',fr:'Arabie Saoudite'},lang:'ar',group:'arab'},
  {f:'🇦🇪',n:{ar:'الإمارات',en:'UAE',fr:'Émirats'},     lang:'ar',group:'arab'},
  {f:'🇰🇼',n:{ar:'الكويت',en:'Kuwait',fr:'Koweït'},     lang:'ar',group:'arab'},
  {f:'🇶🇦',n:{ar:'قطر',en:'Qatar',fr:'Qatar'},          lang:'ar',group:'arab'},
  {f:'🇧🇭',n:{ar:'البحرين',en:'Bahrain',fr:'Bahreïn'},  lang:'ar',group:'arab'},
  {f:'🇴🇲',n:{ar:'عُمان',en:'Oman',fr:'Oman'},          lang:'ar',group:'arab'},
  {f:'🇯🇴',n:{ar:'الأردن',en:'Jordan',fr:'Jordanie'},   lang:'ar',group:'arab'},
  {f:'🇱🇧',n:{ar:'لبنان',en:'Lebanon',fr:'Liban'},      lang:'ar',group:'arab'},
  {f:'🇸🇾',n:{ar:'سوريا',en:'Syria',fr:'Syrie'},        lang:'ar',group:'arab'},
  {f:'🇮🇶',n:{ar:'العراق',en:'Iraq',fr:'Irak'},         lang:'ar',group:'arab'},
  {f:'🇱🇾',n:{ar:'ليبيا',en:'Libya',fr:'Libye'},        lang:'ar',group:'arab'},
  {f:'🇹🇳',n:{ar:'تونس',en:'Tunisia',fr:'Tunisie'},     lang:'fr',group:'arab'},
  {f:'🇩🇿',n:{ar:'الجزائر',en:'Algeria',fr:'Algérie'},  lang:'fr',group:'arab'},
  {f:'🇲🇦',n:{ar:'المغرب',en:'Morocco',fr:'Maroc'},     lang:'fr',group:'arab'},
  {f:'🇾🇪',n:{ar:'اليمن',en:'Yemen',fr:'Yémen'},        lang:'ar',group:'arab'},
  {f:'🇸🇩',n:{ar:'السودان',en:'Sudan',fr:'Soudan'},     lang:'ar',group:'arab'},
  {f:'🇵🇸',n:{ar:'فلسطين',en:'Palestine',fr:'Palestine'},lang:'ar',group:'arab'},
  /* ── Europe / English ── */
  {f:'🇬🇧',n:{ar:'بريطانيا',en:'UK',fr:'Royaume-Uni'},  lang:'en',group:'en'},
  {f:'🇩🇪',n:{ar:'ألمانيا',en:'Germany',fr:'Allemagne'},lang:'en',group:'en'},
  {f:'🇳🇱',n:{ar:'هولندا',en:'Netherlands',fr:'Pays-Bas'},lang:'en',group:'en'},
  {f:'🇸🇪',n:{ar:'السويد',en:'Sweden',fr:'Suède'},      lang:'en',group:'en'},
  {f:'🇺🇸',n:{ar:'أمريكا',en:'USA',fr:'États-Unis'},    lang:'en',group:'en'},
  {f:'🇨🇦',n:{ar:'كندا',en:'Canada',fr:'Canada'},       lang:'en',group:'en'},
  {f:'🇦🇺',n:{ar:'أستراليا',en:'Australia',fr:'Australie'},lang:'en',group:'en'},
  /* ── French-speaking ── */
  {f:'🇫🇷',n:{ar:'فرنسا',en:'France',fr:'France'},      lang:'fr',group:'fr'},
  {f:'🇧🇪',n:{ar:'بلجيكا',en:'Belgium',fr:'Belgique'},  lang:'fr',group:'fr'},
  {f:'🇨🇭',n:{ar:'سويسرا',en:'Switzerland',fr:'Suisse'},lang:'fr',group:'fr'},
];

/* Labels per UI language (before country chosen) */
const CG_LABELS={
  ar:{arab:'العالم العربي 🌙',en:'أوروبا وأمريكا 🌍',fr:'المجال الفرنسي 🇫🇷',
      q:'من أي دولة أنت؟ 🌍',qs:'عشان نتكلم معاك بلغتك'},
  en:{arab:'Arab World 🌙',en:'Europe & Americas 🌍',fr:'French-speaking 🇫🇷',
      q:'Which country are you from? 🌍',qs:'So we can communicate in your language'},
  fr:{arab:'Monde Arabe 🌙',en:'Europe & Amériques 🌍',fr:'Pays francophones 🇫🇷',
      q:'De quel pays venez-vous ? 🌍',qs:'Pour communiquer dans votre langue'},
};

function buildCountryGrid(){
  const grid=document.getElementById('cg-grid');
  if(!grid)return;
  const l=document.documentElement.lang||'ar';
  const lbl=CG_LABELS[l]||CG_LABELS.ar;
  const groups=[
    {key:'arab',label:lbl.arab},
    {key:'en',  label:lbl.en},
    {key:'fr',  label:lbl.fr},
  ];
  grid.innerHTML='';
  groups.forEach(({key,label})=>{
    const grpEl=document.createElement('div');
    grpEl.className='cg-group-lbl';grpEl.textContent=label;
    grid.appendChild(grpEl);
    COUNTRIES.filter(c=>c.group===key).forEach(c=>{
      const btn=document.createElement('button');
      btn.className='cg-btn';
      btn.innerHTML=`<span class="cflag">${c.f}</span><span>${c.n[l]||c.n.ar}</span>`;
      btn.addEventListener('click',()=>{
        applyLanguage(c.lang);
        goStep(2);
      });
      grid.appendChild(btn);
    });
  });
  /* Update question text */
  const qEl=document.querySelector('#s1 .cg-q');
  if(qEl) qEl.innerHTML=lbl.q+'<small>'+lbl.qs+'</small>';
}

/* ── Apply language sitewide ── */
const LANG_COPY={
  ar:{
    dir:'rtl',
    's0-h':'أهلاً! ما اسمك الأول؟ 👋',
    's0-hs':'عشان نتعرف عليك ونخصص تجربتك',
    's0-ph':'اكتب اسمك هنا…',
    's0-btn':'التالي',
    's2-h':'إيه نوعك؟',
    's2-hs':'هنقدر نقترح المنتجات الأنسب ليك',
    's2-f':'بنت','s2-m':'راجل',
    's2-btn':'التالي',
    's3-h':'إيه وصف جسمك؟',
    's3-hs':'دي معلومة مهمة عشان نقترح الصح',
    's3-thin':'نحيف/ة','s3-norm':'طبيعي','s3-over':'زيادة وزن',
    's3-btn':'التالي',
    's4-btn':'شوف توصياتك 🚀',
    's5-btn':'اكتشف المنتجات 🌿',
    'wa-label':'واتساب',
  },
  en:{
    dir:'ltr',
    's0-h':"Hello! What's your first name? 👋",
    's0-hs':'So we can personalise your experience',
    's0-ph':'Type your name here…',
    's0-btn':'Next',
    's2-h':'What is your gender?',
    's2-hs':'To recommend the most suitable products',
    's2-f':'Female','s2-m':'Male',
    's2-btn':'Next',
    's3-h':'How would you describe your body?',
    's3-hs':'Important info to help us suggest the right products',
    's3-thin':'Slim','s3-norm':'Average','s3-over':'Overweight',
    's3-btn':'Next',
    's4-btn':'See your recommendations 🚀',
    's5-btn':'Discover products 🌿',
    'wa-label':'WhatsApp',
  },
  fr:{
    dir:'ltr',
    's0-h':'Bonjour ! Quel est votre prénom ? 👋',
    's0-hs':'Pour personnaliser votre expérience',
    's0-ph':'Tapez votre nom ici…',
    's0-btn':'Suivant',
    's2-h':'Quel est votre genre ?',
    's2-hs':'Pour vous recommander les produits les plus adaptés',
    's2-f':'Femme','s2-m':'Homme',
    's2-btn':'Suivant',
    's3-h':'Comment décrivez-vous votre corps ?',
    's3-hs':'Info importante pour vous suggérer les bons produits',
    's3-thin':'Mince','s3-norm':'Normal','s3-over':'Surpoids',
    's3-btn':'Suivant',
    's4-btn':'Voir mes recommandations 🚀',
    's5-btn':'Découvrir les produits 🌿',
    'wa-label':'WhatsApp',
  },
};

function applyLanguage(lang){
  const c=LANG_COPY[lang]||LANG_COPY.ar;
  const html=document.documentElement;
  html.lang=lang;
  html.dir=c.dir;

  /* helpers */
  const setText=(sel,val)=>{const el=document.querySelector(sel);if(el&&val)el.textContent=val;};
  const setAttr=(sel,attr,val)=>{const el=document.querySelector(sel);if(el&&val)el.setAttribute(attr,val);};

  /* s0 */
  const s0h=document.querySelector('#s0 .step-h');
  if(s0h)s0h.innerHTML=c['s0-h']+'<small>'+c['s0-hs']+'</small>';
  setAttr('#p-name','placeholder',c['s0-ph']);
  const s0btn=document.getElementById('s0-btn');
  if(s0btn)s0btn.innerHTML=c['s0-btn']+' <i class="fas fa-arrow-'+(lang==='ar'?'left':'right')+'" style="font-size:.75rem"></i>';

  /* s1 question */
  buildCountryGrid();

  /* s2 */
  const s2h=document.querySelector('#s2 .step-h');
  if(s2h)s2h.innerHTML=c['s2-h']+'<small>'+c['s2-hs']+'</small>';
  const s2btns=document.querySelectorAll('#s2 .cbtn');
  if(s2btns[0])s2btns[0].innerHTML='<span class="em">👩</span>'+c['s2-f'];
  if(s2btns[1])s2btns[1].innerHTML='<span class="em">👨</span>'+c['s2-m'];
  const s2btn=document.getElementById('s2-btn');
  if(s2btn)s2btn.innerHTML=c['s2-btn']+' <i class="fas fa-arrow-'+(lang==='ar'?'left':'right')+'" style="font-size:.75rem"></i>';

  /* s3 */
  const s3h=document.querySelector('#s3 .step-h');
  if(s3h)s3h.innerHTML=c['s3-h']+'<small>'+c['s3-hs']+'</small>';
  const s3btns=document.querySelectorAll('#s3 .cbtn');
  if(s3btns[0])s3btns[0].innerHTML='<span class="em">🧍</span>'+c['s3-thin'];
  if(s3btns[1])s3btns[1].innerHTML='<span class="em">✅</span>'+c['s3-norm'];
  if(s3btns[2])s3btns[2].innerHTML='<span class="em">⚖️</span>'+c['s3-over'];
  const s3btn=document.getElementById('s3-btn');
  if(s3btn)s3btn.innerHTML=c['s3-btn']+' <i class="fas fa-arrow-'+(lang==='ar'?'left':'right')+'" style="font-size:.75rem"></i>';

  /* s4 */
  const s4btn=document.getElementById('s4-btn');
  if(s4btn)s4btn.textContent=c['s4-btn'];

  /* s5 */
  const s5btn=document.getElementById('s5-btn');
  if(s5btn)s5btn.textContent=c['s5-btn'];

  /* WA FAB label */
  const waLbl=document.querySelector('#wa-fab .wa-lbl');
  if(waLbl)waLbl.textContent=c['wa-label'];

  /* Rebuild social proof toasts to new lang */
  /* (sp-wrap stays, new toasts will use new lang naturally) */
}


/* ══════════ THEME ══════════ */
function initTheme(){const t=localStorage.getItem('pf_theme')||'light';document.documentElement.setAttribute('data-theme',t)}
document.getElementById('theme-btn').addEventListener('click',()=>{
  const cur=document.documentElement.getAttribute('data-theme');
  const next=cur==='light'?'dark':'light';
  document.documentElement.setAttribute('data-theme',next);
  localStorage.setItem('pf_theme',next);
});

/* ══════════ POPUP ══════════ */
let _g=null,_b=null,_p=null;
document.addEventListener('DOMContentLoaded',()=>{
  initTheme();
  try{USER=JSON.parse(localStorage.getItem('pf_u')||'null')}catch{}
  if(USER){closePopup();applyBar();go('home')}
  else{startPopup()}
  initNav();
});

function startPopup(){
  _g=_b=_p=null;
  goStep(0);
  const n0=document.getElementById('s0-btn');
  n0.onclick=()=>{const v=document.getElementById('p-name').value.trim();if(!v){document.getElementById('p-name').classList.add('err');return}goStep(1)};
  document.getElementById('p-name').addEventListener('input',()=>document.getElementById('p-name').classList.remove('err'));
  document.getElementById('p-name').addEventListener('keydown',e=>{if(e.key==='Enter')n0.click()});
  /* ── Build country grid ── */
  buildCountryGrid();

  /* ── s2: gender ── */
  document.querySelectorAll('#s2 .cbtn').forEach(b=>b.addEventListener('click',()=>{_g=b.dataset.g;document.querySelectorAll('#s2 .cbtn').forEach(x=>x.classList.remove('on'));b.classList.add('on')}));
  document.getElementById('s2-btn').onclick=()=>{if(!_g){flash('#s2 .cbtn');return}goStep(3)};
  /* ── s3: body ── */
  document.querySelectorAll('#s3 .cbtn').forEach(b=>b.addEventListener('click',()=>{_b=b.dataset.b;document.querySelectorAll('#s3 .cbtn').forEach(x=>x.classList.remove('on'));b.classList.add('on')}));
  document.getElementById('s3-btn').onclick=()=>{if(!_b){flash('#s3 .cbtn');return}goStep(4)};
  /* ── s4: problem ── */
  document.querySelectorAll('#s4 .crow').forEach(b=>b.addEventListener('click',()=>{_p=b.dataset.p;document.querySelectorAll('#s4 .crow').forEach(x=>x.classList.remove('on'));b.classList.add('on')}));
  document.getElementById('s4-btn').onclick=()=>{
    if(!_p){flash('#s4 .crow');return}
    const name=document.getElementById('p-name').value.trim();
    USER={name,gender:_g,body:_b,problem:_p};
    localStorage.setItem('pf_u',JSON.stringify(USER));
    const{recs,why}=smartRecs(USER);
    const wname=document.getElementById('w-name');
    const wsub=document.getElementById('w-sub');
    const wrec=document.getElementById('w-rec');
    const wem=document.getElementById('w-em');
    if(wem)wem.textContent=_g==='female'?'🌸':'💪';
    const l=document.documentElement.lang||'ar';
    if(l==='en'){
      if(wname)wname.textContent='Welcome, '+name+'!';
      if(wsub)wsub.textContent='Based on your answers, here are your 100% personalised recommendations.';
    } else if(l==='fr'){
      if(wname)wname.textContent='Bienvenue, '+name+' !';
      if(wsub)wsub.textContent='Basé sur vos réponses, voici vos recommandations personnalisées à 100%.';
    } else {
      if(wname)wname.textContent='أهلاً يا '+name+'!';
      if(wsub)wsub.textContent='على أساس إجاباتك جاهزة ليك توصيات مخصصة 100%';
    }
    /* Build rec cards HTML */
    const recCards=recs.map((id,i)=>{
      const prod=PRODUCTS[id];
      if(!prod)return'';
      const grad=CARD_GRADS[id]||'linear-gradient(135deg,#1B4332,#2D6A4F)';
      const imgHtml=prod.img
        ?`<img src="${prod.img}" alt="${prod.nm}" loading="lazy">`
        :`<div class="w-rec-grad" style="background:${grad}">🌿</div>`;
      return`<div class="w-rec-card" style="--i:${i}" onclick="go('product','${id}')">
        <div class="w-rec-img-wrap">${imgHtml}</div>
        <div class="w-rec-info">
          <div class="w-rec-name">${prod.nm}</div>
          <div class="w-rec-kit">${prod.kit||''}</div>
        </div>
      </div>`;
    }).join('');
    if(wrec)wrec.innerHTML=`<div class="w-rec-grid">${recCards}</div><div class="w-rec-why">${why}</div>`;
    applyBar();goStep(5);
  };
  document.getElementById('s5-btn').onclick=()=>{closePopup();go('home')};
}

function goStep(n){
  [0,1,2,3,4,5].forEach(i=>{
    const s=document.getElementById(`s${i}`);if(s)s.classList.toggle('on',i===n);
    const d=document.getElementById(`dot${i}`);if(d)d.classList.toggle('on',i===n);
  });
}
function flash(sel){document.querySelectorAll(sel).forEach(b=>{b.style.borderColor='var(--red)';setTimeout(()=>b.style.borderColor='',1400)})}
function closePopup(){const el=document.getElementById('popup');el.classList.add('closing');setTimeout(()=>el.classList.add('gone'),300)}

/* ══════════ NAV SCROLL ══════════ */
function initNav(){
  window.addEventListener('scroll',()=>{
    document.getElementById('nav').classList.toggle('scrolled',window.scrollY>60);
  },{passive:true});
}

/* ══════════ SMART RECS ══════════ */
function smartRecs(user){
  const{gender,body,problem}=user;
  let recs=[],why='';
  if(problem==='thinness'){recs=['el3','el2','el4','b1'];why=`بناءً على مشكلة النحافة، <strong>MaxBulk</strong> هيرفع سعراتك وبيبني العضلة بشكل حقيقي، و<strong>Creatine</strong> هيزيد قوتك.`}
  else if(problem==='fat'){recs=['el1','el4','s1','l1'];why=`لمشكلة الدهون، <strong>Burnmode</strong> هيحرق الدهون العنيدة و<strong>ISO Pro</strong> هيحافظ على عضلاتك.`}
  else if(problem==='hair'){recs=['b2','b3','b1','pk1'];why=`لتساقط الشعر والجفاف، <strong>Be Strong Kit</strong> الكاملة هي الحل المثالي.`}
  else if(problem==='skin'){recs=['l1','s1','e1','be1'];why=`لجفاف البشرة، <strong>Your Love Lotion</strong> يعطي ترطيب يدوم 12 ساعة.`}
  else if(problem==='acne'){recs=['e3','e2','s1','be1'];why=`لحب الشباب، <strong>Face Wash</strong> بزيت شجرة الشاي مضاد للبكتيريا.`}
  else if(problem==='energy'){recs=['el2','el4','el1','el3'];why=`لضعف الطاقة، <strong>Creatine</strong> يزيد طاقتك في التمرين فوراً.`}
  else{recs=gender==='female'?['l1','b2','s1','e2']:['el1','el4','el2','el3'];why=`اخترنا ليك أكثر المنتجات شمولاً ونتائج. كل منتج طبيعي 100% وآمن للاستخدام اليومي.`}
  return{recs:[...new Set(recs)].slice(0,4),why};
}

/* ══════════ BAR ══════════ */
function applyBar(){
  if(!USER)return;
  const bar=document.getElementById('bar');
  bar.innerHTML=USER.gender==='female'?`أهلاً يا <strong>${USER.name}</strong> ❤️ — توصياتك المخصصة في انتظارك`:`أهلاً يا <strong>${USER.name}</strong> 💪 — اكتشف قوتك مع PUREFORM`;
  bar.classList.add('on');
}

/* ══════════ PAGE TRANSITION ══════════ */
let _transitioning=false;
function go(page,id){
  if(_transitioning)return;
  _transitioning=true;
  const app=document.getElementById('app');

  /* fast fade-out */
  app.classList.add('pg-out');

  setTimeout(()=>{
    const fns={home:renderHome,beauty:renderBeauty,elevate:renderElevate,tips:renderTips,contact:renderContact,product:()=>renderProduct(id)};
    app.innerHTML=(fns[page]||renderHome)();
    window.scrollTo({top:0,behavior:'instant'});

    /* nav highlight */
    document.querySelectorAll('.n-lnk').forEach(el=>el.classList.remove('cur'));
    const map={home:'الرئيسية',beauty:'RZN Beauty',elevate:'Elevate',tips:'Tips & Goals',contact:'تواصل معنا'};
    const pg=page==='product'?(ELEVATE.some(p=>p.id===id)?'elevate':'beauty'):page;
    document.querySelectorAll('.n-lnk').forEach(el=>{if(el.textContent.trim()===(map[pg]||''))el.classList.add('cur')});

    /* fade-in on next paint */
    app.classList.remove('pg-out');
    app.classList.add('pg-in');

    _transitioning=false;
    initReveal();
    initCardTilt();
    initHeroParallax();

    /* clean up class after transition */
    setTimeout(()=>app.classList.remove('pg-in'),160);
  },120);
}

function toggleDrawer(){
  document.getElementById('drawer').classList.toggle('open');
  document.getElementById('ham').classList.toggle('open');
}

/* ══════════ SCROLL REVEAL ══════════ */
function initReveal(){
  const io=new IntersectionObserver(entries=>{
    entries.forEach(e=>{
      if(e.isIntersecting){
        if(e.target.dataset.stagger!==undefined){e.target.classList.add('in')}
        else{e.target.classList.add('in')}
        io.unobserve(e.target);
      }
    });
  },{threshold:.07,rootMargin:'0px 0px -30px 0px'});
  document.querySelectorAll('.rv:not(.in),.rv-left:not(.in),.rv-scale:not(.in),[data-stagger]:not(.in)').forEach(el=>io.observe(el));
}

/* ══════════ CARD 3D TILT ══════════ */
function initCardTilt(){
  document.querySelectorAll('.pcard,.ec,.tip-card').forEach(card=>{
    card.addEventListener('mousemove',e=>{
      const r=card.getBoundingClientRect();
      const x=(e.clientX-r.left)/r.width-.5;
      const y=(e.clientY-r.top)/r.height-.5;
      card.style.transform=`translateY(-10px) rotateY(${x*8}deg) rotateX(${-y*6}deg)`;
    });
    card.addEventListener('mouseleave',()=>{
      card.style.transform='';
    });
  });
}

/* ══════════ HERO PARALLAX ══════════ */
function initHeroParallax(){
  const hero=document.querySelector('.hero');
  if(!hero)return;
  const orbs=hero.querySelectorAll('.orb');
  hero.addEventListener('mousemove',e=>{
    const r=hero.getBoundingClientRect();
    const x=(e.clientX-r.left)/r.width-.5;
    const y=(e.clientY-r.top)/r.height-.5;
    orbs.forEach((orb,i)=>{
      const d=(i+1)*18;
      orb.style.transform=`translate(${x*d}px,${y*d}px)`;
    });
  },{passive:true});
  hero.addEventListener('mouseleave',()=>{orbs.forEach(o=>o.style.transform='')});
}

/* ══════════ HERO CANVAS PARTICLES ══════════ */
function initHeroCanvas(){
  const canvas=document.getElementById('hero-canvas');
  if(!canvas)return;
  const ctx=canvas.getContext('2d');
  let W,H,particles=[];
  function resize(){W=canvas.width=canvas.offsetWidth;H=canvas.height=canvas.offsetHeight}
  resize();window.addEventListener('resize',resize,{passive:true});
  for(let i=0;i<45;i++)particles.push({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.4,vy:(Math.random()-.5)*.4,r:Math.random()*1.5+.5,a:Math.random()*.5+.1});
  function draw(){
    ctx.clearRect(0,0,W,H);
    particles.forEach(p=>{
      p.x+=p.vx;p.y+=p.vy;
      if(p.x<0)p.x=W;if(p.x>W)p.x=0;if(p.y<0)p.y=H;if(p.y>H)p.y=0;
      ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
      ctx.fillStyle=`rgba(82,183,136,${p.a})`;ctx.fill();
    });
    requestAnimationFrame(draw);
  }
  draw();
}

/* ══════════ RIPPLE ══════════ */
document.addEventListener('click',e=>{
  const btn=e.target.closest('.btn,.pcta,.n-wa');
  if(!btn)return;
  const r=btn.getBoundingClientRect();
  const ripple=document.createElement('span');
  const size=Math.max(r.width,r.height)*2;
  ripple.style.cssText=`position:absolute;width:${size}px;height:${size}px;border-radius:50%;background:rgba(255,255,255,.25);transform:scale(0);left:${e.clientX-r.left-size/2}px;top:${e.clientY-r.top-size/2}px;pointer-events:none;animation:rippleAnim .6s ease forwards`;
  btn.appendChild(ripple);
  setTimeout(()=>ripple.remove(),700);
});
const rippleStyle=document.createElement('style');
rippleStyle.textContent='@keyframes rippleAnim{to{transform:scale(1);opacity:0}}';
document.head.appendChild(rippleStyle);

/* ══════════ HOME ══════════ */
function renderHome(){
  const best=Object.values(PRODUCTS).filter(p=>p.best);
  return`<div>
<section class="hero">
  <canvas id="hero-canvas"></canvas>
  <div class="orb"></div><div class="orb"></div><div class="orb"></div>
  <div class="hero-c">
    <div class="hero-lbl">Natural Power · Real Results</div>
    <h1 class="hero-h1">PUREFORM</h1>
    <p class="hero-tagline">by Risen Live</p>
    <div class="hero-verse">
      <p>﴿ وَأَنْ لَيْسَ لِلْإِنْسَانِ إِلَّا مَا سَعَى (39)<br>وَأَنَّ سَعْيَهُ سَوْفَ يُرَى (40)<br>ثُمَّ يُجْزَاهُ الْجَزَاءَ الْأَوْفَى (41) ﴾</p>
      <cite>سورة النجم</cite>
    </div>
    <div class="hero-badges">
      <span class="hbadge"><i class="fas fa-leaf"></i> طبيعي 100%</span>
      <span class="hbadge"><i class="fas fa-shield-alt"></i> آمن لكل البشرة</span>
      <span class="hbadge"><i class="fas fa-check-circle"></i> نتائج مجربة</span>
    </div>
    <div class="hero-btns">
      <button class="btn btn-gold" onclick="go('beauty')">اطلب دلوقتي 🚀</button>
      <button class="btn btn-ghost" onclick="go('tips')">ابدأ رحلتك 💪</button>
    </div>
  </div>
  <div class="scroll-hint"><i class="fas fa-chevron-down"></i></div>
</section>
${renderRecs()}
<section class="sec bg-warm">
  <div class="mw">
    <div class="sec-hdr rv"><span class="sec-lbl">الأكثر مبيعاً</span><h2 class="sec-h">Best <em>Sellers</em></h2><p class="sec-d">منتجاتنا اللي حققت أعلى رضا عملائنا بنتائج حقيقية ومجربة</p></div>
    <div class="pgrid" data-stagger>${best.map((p,i)=>makeCard(p,i)).join('')}</div>
  </div>
</section>
<div class="trust-strip" data-stagger>
  ${[['fas fa-seedling','طبيعي 100%','مكونات نقية بدون مواد صناعية'],['fas fa-shield-heart','آمن وموثوق','مجرب على آلاف العملاء'],['fas fa-chart-line','نتائج مجربة','فرق حقيقي ومحسوس'],['fas fa-truck-fast','توصيل سريع','لجميع المحافظات']].map(([ic,h,p])=>`<div class="tc"><i class="${ic}"></i><h5>${h}</h5><p>${p}</p></div>`).join('')}
</div>
${renderShipping()}
<div class="stmt-sec">
  <p class="stmt-q rv">"احنا مش بنبيع منتجات وبس —<br>احنا بنساعدك تبقى <em>أفضل نسخة من نفسك</em>"</p>
  <span class="stmt-src rv">PUREFORM · Risen Live</span><br>
  <button class="btn btn-gold rv" onclick="go('contact')" style="margin-top:2rem">اطلب الآن 🚀</button>
</div>
</div>`;
}

/* ══════════ RECS ══════════ */
function renderRecs(){
  if(!USER)return'';
  const{recs,why}=smartRecs(USER);
  const f=USER.gender==='female';
  const cross=f?`ولو عندك أحد من الرجالة 👨 — <a href="#" onclick="go('elevate');return false">Elevate</a> مناسب ليهم جداً 💪`:`ولو عندك زوجة / خطيبة / أخت 👩 — <a href="#" onclick="go('beauty');return false">RZN Beauty</a> هدية مثالية 🎁`;
  return`<section class="recs-sec">
  <div class="mw">
    <div class="recs-hdr rv"><div class="recs-av">${f?'👩':'👨'}</div><div><div class="recs-title">توصيات خصيصاً <span>ليك</span> يا ${USER.name}</div><div style="font-size:.75rem;color:var(--ink3);font-weight:300;margin-top:.15rem">بناءً على مشكلتك وحالتك الجسدية</div></div></div>
    <div class="recs-row" data-stagger>${recs.map(id=>{const p=PRODUCTS[id];if(!p)return'';return`<div class="ri" onclick="go('product','${id}')"><span class="ri-em">${p.em}</span><div><div class="ri-nm">${p.nm}</div><div class="ri-pr">${p.pr.toLocaleString()} جنيه</div></div></div>`}).join('')}</div>
    <div class="why-box rv d1">${why}</div>
    <div class="cross-box rv d2">${cross}</div>
  </div>
</section>`;
}

/* ══════════ SHIPPING ══════════ */
function renderShipping(){
  return`<div class="ship-sec"><div class="mw">
  <div class="sec-hdr c rv"><span class="sec-lbl">خدمة الشحن</span><h2 class="sec-h lgt">وصّلناهالك <em>أينما كنت</em></h2></div>
  <div class="ship-grid" data-stagger>
    ${[['fas fa-truck-fast','شحن سريع لكل مصر','توصيل احترافي لجميع محافظات الجمهورية'],['fas fa-globe','شحن دولي +16 دولة','نوصّل لأكثر من 16 دولة حول العالم'],['fas fa-box-open','تغليف آمن ومحكم','منتجاتك بتوصلك سليمة 100%'],['fas fa-bolt','تجهيز الطلبات سريع','بنجهز طلبك في أسرع وقت ممكن']].map(([i,h,p])=>`<div class="sc"><div class="sc-i-wrap"><i class="${i}"></i></div><h4>${h}</h4><p>${p}</p></div>`).join('')}
  </div>
</div></div>`;
}

/* ══════════ PRODUCT CARD ══════════ */
function makeCard(p,i=0){
  const grad=CARD_GRADS[p.id]||'linear-gradient(135deg,#1B4332,#2D6A4F)';
  const save=p.orig-p.pr;
  const imgEl=p.img?`<img class="pc-prod-img" src="${p.img}" alt="${p.nm}" loading="lazy">`:'';
  return`<div class="pcard rv-scale d${i%4+1}" onclick="go('product','${p.id}')">
  <div class="pc-top" style="background:${grad}">
    ${imgEl}<span class="pc-em">${p.em}</span>
    <div class="pc-overlay"></div>
    <div class="pc-badges">${p.badge?`<span class="pb-best">${p.badge}</span>`:''}${p.best?`<span class="pb-hot"><i class="fas fa-fire" style="font-size:.55rem"></i> مطلوب</span>`:''}</div>
    <div class="pc-stars-overlay">${p.best?'★★★★★':'★★★★☆'}</div>
    <div class="pc-discount">وفر ${save} ج</div>
    <button class="wl-btn" id="wl-${p.id}" onclick="event.stopPropagation();toggleWishlist('${p.id}')" title=""><i class="fas fa-heart"></i></button>
  </div>
  <div class="pc-body">
    <div class="pc-kit">${p.kit}</div>
    <div class="pc-name">${p.nm}</div>
    <div class="pc-pills">${(p.tags||[]).slice(0,3).map(t=>`<span class="pc-pill">${t}</span>`).join('')}</div>
    <div class="pc-benefits">${(p.benefits||[]).slice(0,3).map(b=>`<div class="pc-ben">${b}</div>`).join('')}</div>
    <div class="pc-foot"><div class="pc-prices"><div class="pc-price">${p.pr.toLocaleString()}<sup> جنيه</sup></div><div class="pc-orig">${p.orig.toLocaleString()} ج</div></div><div class="pc-action"><i class="fas fa-arrow-left"></i></div></div>
    <button class="atc-btn" id="atc-${p.id}" onclick="event.stopPropagation();addToCart('${p.id}')" ><i class="fas fa-shopping-bag"></i> <span>${cartT('atc')}</span></button>
  </div>
</div>`;
}

/* ══════════ BEAUTY ══════════ */
function renderBeauty(){
  const tabs=KITS.map((k,i)=>`<button class="ktab${i===0?' on':''}" data-k="${k.key}" onclick="switchKit('${k.key}')">${k.icon} ${k.label}</button>`).join('');
  const panels=KITS.map((k,i)=>`<div class="kit-panel${i===0?' on':''}" id="kp-${k.key}"><div class="prows">${k.items.map(p=>`
  <div class="prow" onclick="go('product','${p.id}')">
    <div class="prow-thumb" style="background:${CARD_GRADS[p.id]||'linear-gradient(135deg,#1B4332,#2D6A4F)'}">${p.img?`<img src="${p.img}" alt="${p.nm}">`:`<span style="font-size:1.6rem">${p.em}</span>`}</div>
    <div><div class="pr-nm">${p.nm}${p.badge?`<span class="pr-best-tag">${p.badge}</span>`:''}</div><div class="pr-tags">${p.tags.slice(0,3).map(t=>`<span class="ptag">${t}</span>`).join('')}</div><div class="pr-desc">${p.benefits.slice(0,2).join(' · ')}</div></div>
    <div class="pr-r"><div><div class="pr-price">${p.pr.toLocaleString()} ج</div><div class="pr-orig">${p.orig.toLocaleString()} ج</div></div><span class="pr-btn">تفاصيل <i class="fas fa-arrow-left" style="font-size:.6rem"></i></span></div>
  </div>`).join('')}</div></div>`).join('');
  return`<div><div class="ph"><div class="ph-in"><span class="ph-lb">عناية طبيعية · Natural Beauty</span><h1 class="ph-h">RZN Beauty</h1><p class="ph-d">كل منتج مصنوع بعناية من أفضل المكونات الطبيعية لأفضل نتيجة</p></div></div>
<section class="sec bg-warm"><div class="mw"><div class="kit-tabs rv">${tabs}</div>${panels}<div class="rv d2">${dlv()}</div></div></section></div>`;
}
function switchKit(k){
  document.querySelectorAll('.ktab').forEach(t=>t.classList.toggle('on',t.dataset.k===k));
  document.querySelectorAll('.kit-panel').forEach(p=>p.classList.toggle('on',p.id===`kp-${k}`));
}

/* ══════════ ELEVATE ══════════ */
function renderElevate(){
  return`<div><div class="ph" style="background:linear-gradient(135deg,#050D09,#0F2318)">
  <div class="ph-in"><span class="ph-lb">Performance Nutrition · تغذية رياضية</span><h1 class="ph-h">Elevate 💪</h1><p class="ph-d">مكملات طبيعية عالية الجودة — نتائج حقيقية ومجربة لأقصى أداء</p></div></div>
<section class="sec" style="background:#070F0A"><div class="mw">
  <div class="el-grid" data-stagger>${ELEVATE.map(p=>`
  <div class="ec rv-scale" onclick="go('product','${p.id}')">
    <div class="ec-top" style="background:linear-gradient(135deg,${p.color||'#1B4332'},rgba(0,0,0,.3));position:relative;overflow:hidden">
      ${p.img?`<img src="${p.img}" alt="${p.nm}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:fill;opacity:.35">`:''}<span class="ec-em" style="position:relative;z-index:1">${p.em}</span>
      <div class="ec-price-blk" style="position:relative;z-index:1"><div class="ec-price">${p.pr.toLocaleString()}<span style="font-size:.65rem;font-family:Tajawal;font-weight:300"> ج</span></div><div class="ec-orig">${p.orig.toLocaleString()} ج</div><div class="ec-save">وفر ${p.orig-p.pr} ج</div></div>
    </div>
    <div class="ec-body"><div class="ec-name">${p.nm}</div><div class="ec-sub">${p.sub}</div>${p.macros.length?`<div class="ec-macros">${p.macros.map(m=>`<span class="ec-mac">${m}</span>`).join('')}</div>`:''}<div class="ec-uses">${p.uses.map(u=>`<div class="ec-use">${u}</div>`).join('')}</div></div>
    <div class="ec-cta" onclick="event.stopPropagation();window.open('https://wa.me/201286332777?text=عايز أطلب ${encodeURIComponent(p.nm)}','_blank')"><i class="fab fa-whatsapp"></i> اطلب الآن</div>
  </div>`).join('')}</div>
  <div class="rv d2" style="color:rgba(255,255,255,.4);text-align:center;font-size:.84rem;margin-top:1.5rem;padding:1rem;font-weight:300">ولو عندك زوجة / خطيبة / أخت 👩 — <a href="#" onclick="go('beauty');return false" style="color:var(--gold2);font-weight:600">RZN Beauty</a> هدية مثالية ليها 🎁</div>
  <div class="rv d3">${dlv()}</div>
</div></section></div>`;
}

/* ══════════ TIPS ══════════ */
function renderTips(){
  const cards=[
    {em:'🏗️',h:'للنحيفين — زيادة الوزن',col:'var(--g600)',rows:[{i:'fas fa-plus',t:[{c:'MaxBulk'},' + ',{c:'ISO Pro'},' يومياً']},{i:'fas fa-bolt',t:[{c:'Creatine'},' قبل التمرين بـ ٣٠ دقيقة']},{i:'fas fa-utensils',t:['٥–٦ وجبات صغيرة على مدار اليوم']},{i:'fas fa-tint',t:['٣–٥ لتر ماء يومياً على الأقل']},{i:'fas fa-dumbbell',t:['تمارين مقاومة ٤-٥ أيام أسبوع']},{i:'fas fa-moon',t:['نوم ٧-٩ ساعات — العضلة بتنمو وإنت نايم']}]},
    {em:'🔥',h:'لفقدان الدهون',col:'var(--red)',rows:[{i:'fas fa-fire',t:[{c:'Burnmode',s:'var(--red)'},' صباحاً قبل الفطور']},{i:'fas fa-running',t:['Cardio ٣٠-٤٥ دقيقة، ٤-٥ أيام أسبوع']},{i:'fas fa-ban',t:['تقليل السكريات والكارب المكرر']},{i:'fas fa-drumstick-bite',t:[{c:'ISO Pro',s:'var(--red)'},' بروتين نقي بعد التمرين']},{i:'fas fa-moon',t:['نوم منتظم — قلة النوم تزيد الدهون']}]},
    {em:'💎',h:'الحفاظ على العضلات',col:'#3A7ABE',rows:[{i:'fas fa-plus',t:[{c:'ISO Pro',s:'#3A7ABE'},' بعد كل تمرين مباشرة']},{i:'fas fa-dumbbell',t:['تمارين مقاومة مستمرة ومنتظمة']},{i:'fas fa-water',t:['ترطيب جيد يومياً']},{i:'fas fa-balance-scale',t:['وجبات متوازنة بروتين + كارب']}]},
    {em:'✨',h:'عناية الشعر والبشرة',col:'#9B4F96',rows:[{i:'fas fa-star',t:[{c:'Be Strong',s:'#9B4F96'},' شامبو + مكيف مرتين أسبوع']},{i:'fas fa-spray-can',t:[{c:'Hair Mist',s:'#9B4F96'},' يومياً للحماية والترطيب']},{i:'fas fa-pump-soap',t:[{c:'Body Lotion',s:'#9B4F96'},' بعد الاستحمام مباشرة']},{i:'fas fa-droplet',t:['شرب ٢+ لتر ماء — الجلد يتحسن من الداخل']}]},
  ];
  function mkRow(r,col){const pts=r.t.map(x=>typeof x==='string'?x:`<span class="chip" style="background:${x.s||'var(--g800)'}">${x.c}</span>`).join('');return`<div class="tip-row"><i class="${r.i}" style="color:${col};flex-shrink:0;width:14px;text-align:center"></i><span>${pts}</span></div>`}
  return`<div><div class="ph"><div class="ph-in"><span class="ph-lb">Tips & Goals · نصائح وأهداف</span><h1 class="ph-h">خطتك<br>لهدفك</h1><p class="ph-d">دليلك الذكي للوصول لهدفك بأسرع وأصح طريقة ممكنة</p></div></div>
<section class="sec bg-warm"><div class="mw"><div class="tips-grid" data-stagger>
  ${cards.map((c,i)=>`<div class="tip-card" style="--tip-col:${c.col}"><div class="tip-top"><span class="tip-ico">${c.em}</span><div class="tip-h">${c.h}</div></div><div class="tip-rows">${c.rows.map(r=>mkRow(r,c.col)).join('')}</div></div>`).join('')}
</div></div></section>
<div class="stmt-sec" style="padding:clamp(3.5rem,6vw,5rem) 5%"><p class="stmt-q rv">"البداية أصعب جزء — لكن بعد أول <em>أسبوعين</em> هتشوف الفرق بنفسك"</p><button class="btn btn-gold rv" onclick="go('contact')" style="margin-top:2rem">اطلب الآن 🚀</button></div></div>`;
}

/* ══════════ CONTACT ══════════ */
function renderContact(){
  const hint=USER?(USER.gender==='female'?`يا ${USER.name}، تصفحي <a href="#" onclick="go('beauty');return false">RZN Beauty</a> وابعتيلنا عشان نساعدك تختاري 💚`:`يا ${USER.name}، تصفح <a href="#" onclick="go('elevate');return false">Elevate</a> وابعتلنا عشان نساعدك تبدأ صح 💚`):'';
  return`<div class="contact-wrap"><div class="cc">
  <div class="cc-logo">PUREFORM</div><div class="cc-by">by risen live</div>
  <p class="cc-txt rv">فريقنا مستعد لمساعدتك في اختيار المنتج الأنسب وإتمام طلبك بسهولة وسرعة.</p>
  ${hint?`<div class="cross-box rv" style="margin-bottom:1.5rem;text-align:center">${hint}</div>`:''}
  <a class="wa-main rv" href="https://wa.me/201286332777?text=أهلاً PUREFORM 👋 عايز أعرف أكثر" target="_blank"><i class="fab fa-whatsapp"></i> تواصل على واتساب</a>
  <div class="cc-meta rv d1"><div class="cc-mr"><i class="fas fa-phone"></i> 01286332777</div><div class="cc-mr"><i class="fas fa-globe"></i> شحن دولي لأكثر من 16 دولة 🌍</div><div class="cc-mr"><i class="fas fa-truck-fast"></i> توصيل سريع لكل المحافظات</div><div class="cc-mr"><i class="fas fa-clock"></i> رد في أقل من ساعة</div><div class="cc-mr"><a href="https://www.tiktok.com/@pureform77" target="_blank" style="display:flex;align-items:center;gap:.45rem;color:var(--ink3);text-decoration:none;transition:color var(--t)" onmouseover="this.style.color='#69C9D0'" onmouseout="this.style.color='var(--ink3)'"><i class="fab fa-tiktok" style="color:#69C9D0"></i> @pureform77</a></div></div>
  <div class="cc-grid rv d2">
    <div class="c-tile" onclick="go('beauty')"><i class="fas fa-spa"></i><strong>RZN Beauty</strong><span>عناية طبيعية</span></div>
    <div class="c-tile" onclick="go('elevate')"><i class="fas fa-dumbbell"></i><strong>Elevate</strong><span>تغذية رياضية</span></div>
    <div class="c-tile" onclick="go('tips')"><i class="fas fa-bullseye"></i><strong>Tips & Goals</strong><span>خطتك لهدفك</span></div>
    <div class="c-tile" onclick="window.open('https://www.tiktok.com/@pureform77','_blank')"><i class="fab fa-tiktok" style="color:#69C9D0"></i><strong>TikTok</strong><span>@pureform77</span></div>
  </div>
</div></div>`;
}

/* ══════════ PRODUCT DETAIL ══════════ */
function renderProduct(id){
  const p=PRODUCTS[id];if(!p)return renderHome();
  const back=ELEVATE.some(x=>x.id===id)?'elevate':'beauty';
  const revs=REVIEWS[id]||[];
  const avg=(revs.reduce((a,r)=>a+r.s,0)/revs.length).toFixed(1);
  const grad=CARD_GRADS[p.id]||'linear-gradient(135deg,#1B4332,#2D6A4F)';
  const starStr=s=>'★'.repeat(s)+'☆'.repeat(5-s);
  return`<div class="dw">
  <div class="d-back" onclick="go('${back}')"><i class="fas fa-arrow-right"></i> رجوع</div>
  <div class="dgrid">
    <div class="d-imgs rv-scale">
      <div class="d-main" style="background:${grad}">${p.img?`<img class="d-prod-img" src="${p.img}" alt="${p.nm}" loading="lazy">`:''}</div>
      <div class="d-thumbs">${['🌿','✨','🍃'].map((e,i)=>`<div class="d-thumb${i===0?' on':''}">${e}</div>`).join('')}</div>
    </div>
    <div class="rv">
      <div class="d-kit">${p.kit}</div>
      <h1 class="d-name">${p.nm}</h1>
      ${discountCardHTML()}
      <div class="d-prow"><span class="d-price">${p.pr.toLocaleString()}</span><span class="d-orig">${p.orig.toLocaleString()} ج</span><span class="d-save">وفر ${p.orig-p.pr} جنيه</span></div>
      ${p.best?`<div class="d-scar"><span><i class="fas fa-fire"></i> الأكثر مبيعاً</span><span><i class="fas fa-hourglass-half"></i> عرض محدود</span><span><i class="fas fa-star"></i> تقييم ممتاز</span></div>`:''}
      <div class="d-sec"><div class="d-sch"><i class="fas fa-leaf"></i> المكونات الأساسية</div><div class="d-tags">${(p.tags||[]).map(t=>`<span class="dtag">${t}</span>`).join('')}</div></div>
      <div class="d-sec"><div class="d-sch"><i class="fas fa-check-circle"></i> الفوائد والاستخدام الكامل</div><div class="d-uses" data-stagger>${(p.uses||[]).map(u=>`<div class="d-use">${u}</div>`).join('')}</div></div>
      ${p.macros&&p.macros.length?`<div class="d-sec"><div class="d-sch"><i class="fas fa-chart-bar"></i> القيم الغذائية</div><div class="d-tags">${p.macros.map(m=>`<span class="dtag" style="background:var(--g800);color:#fff;border:none">${m}</span>`).join('')}</div></div>`:''}
      <button class="d-atc-btn" id="atc-detail-${p.id}" onclick="addToCart('${p.id}');updateAtcDetail('${p.id}')"><i class="fas fa-shopping-bag" style="font-size:1.1rem"></i> <span id="atc-detail-txt">${cartT('atc')}</span></button>
      <a class="btn btn-wa" href="https://wa.me/201286332777?text=عايز أطلب ${encodeURIComponent(p.nm)}" target="_blank" style="width:100%;justify-content:center;padding:1.1rem;border-radius:var(--r-sm);font-size:1rem;margin-top:.65rem"><i class="fab fa-whatsapp" style="font-size:1.3rem"></i> اطلب الآن عبر واتساب</a>
      <div style="margin-top:2rem" id="reviews-section-${p.id}">
        ${renderReviewsSection(p.id, revs, avg)}
      </div>
    </div>
  </div>
  <div style="max-width:960px;margin-top:3rem">${dlv()}</div>
</div>`;
}

/* ══════════ DELIVERY BOX ══════════ */
function dlv(){
  return`<div class="dlv rv"><h5><i class="fas fa-truck-fast"></i> خدمة الشحن والتوصيل</h5><div class="dlv-grid"><div class="dlv-it">شحن سريع لجميع محافظات مصر</div><div class="dlv-it">شحن دولي لأكثر من 16 دولة</div><div class="dlv-it">تغليف آمن ومحكم</div><div class="dlv-it">تجهيز سريع للطلبات</div></div></div>`;
}

/* Patch go() to also init canvas for home */
const _goBase=go;
window.go=function(page,id){
  _goBase(page,id);
  if(page==='home')setTimeout(initHeroCanvas,400);
};
/* Ensure first load triggers canvas */
document.addEventListener('DOMContentLoaded',()=>{setTimeout(()=>{if(document.getElementById('hero-canvas'))initHeroCanvas()},500)});

/* ═══════════════════════════════════════════════════════
   SOCIAL PROOF & URGENCY NOTIFICATION SYSTEM
═══════════════════════════════════════════════════════ */
(function(){
  const css=`
    #sp-wrap{
      position:fixed;bottom:86px;left:1.1rem;z-index:800;
      display:flex;flex-direction:column-reverse;gap:.5rem;
      align-items:flex-start;pointer-events:none;
      max-width:min(300px,calc(100vw - 2.2rem));
    }
    [dir="ltr"] #sp-wrap{left:auto;right:1.1rem;align-items:flex-end;}
    @media(min-width:560px){#sp-wrap{bottom:96px}}
    .spt{
      display:flex;align-items:center;gap:.58rem;
      background:var(--surface);
      border:1px solid var(--border);
      border-left:3px solid var(--spt-accent,#52B788);
      border-radius:12px;
      padding:.55rem .8rem .55rem .65rem;
      box-shadow:0 6px 28px rgba(0,0,0,.13),0 1px 6px rgba(0,0,0,.07);
      pointer-events:auto;cursor:pointer;
      width:100%;
      transform:translateX(-115%);opacity:0;
      transition:transform .46s cubic-bezier(.34,1.56,.64,1),
                 opacity .38s ease;
      will-change:transform,opacity;
      position:relative;overflow:hidden;
    }
    [dir="ltr"] .spt{
      border-left:none;border-right:3px solid var(--spt-accent,#52B788);
      transform:translateX(115%);
    }
    [data-theme="dark"] .spt{
      background:rgba(21,32,25,.96);
      box-shadow:0 8px 30px rgba(0,0,0,.42);
    }
    .spt.sp-in{transform:translateX(0)!important;opacity:1}
    .spt.sp-out{
      transform:translateX(-115%)!important;opacity:0;
      transition:transform .3s cubic-bezier(.55,0,1,.45),opacity .26s ease;
    }
    [dir="ltr"] .spt.sp-out{transform:translateX(115%)!important}
    .spt::before{
      content:'';position:absolute;inset:0;
      background:linear-gradient(90deg,transparent 0%,rgba(255,255,255,.055) 50%,transparent 100%);
      transform:translateX(-100%);
      animation:sptShimmer 3s ease-in-out infinite;
    }
    @keyframes sptShimmer{0%{transform:translateX(-100%)}100%{transform:translateX(250%)}}
    .spt-ico{
      width:32px;height:32px;border-radius:9px;flex-shrink:0;
      display:flex;align-items:center;justify-content:center;
      font-size:.9rem;
      background:color-mix(in srgb,var(--spt-accent,#52B788) 16%,transparent);
      position:relative;z-index:1;
    }
    .spt-body{flex:1;min-width:0;position:relative;z-index:1;}
    .spt-title{font-size:.775rem;font-weight:700;color:var(--ink);line-height:1.3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .spt-sub{font-size:.66rem;color:var(--ink3);font-weight:400;margin-top:.08rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .spt-dot{
      width:6px;height:6px;border-radius:50%;flex-shrink:0;
      background:var(--spt-accent,#52B788);
      animation:sptPulse 1.9s ease-in-out infinite;
    }
    @keyframes sptPulse{
      0%{box-shadow:0 0 0 0 color-mix(in srgb,var(--spt-accent,#52B788) 65%,transparent)}
      70%{box-shadow:0 0 0 6px color-mix(in srgb,var(--spt-accent,#52B788) 0%,transparent)}
      100%{box-shadow:0 0 0 0 color-mix(in srgb,var(--spt-accent,#52B788) 0%,transparent)}
    }
    .spt-bar{position:absolute;bottom:0;left:0;right:0;height:2px;background:color-mix(in srgb,var(--spt-accent,#52B788) 22%,transparent);}
    .spt-fill{height:100%;background:var(--spt-accent,#52B788);transform-origin:left;}
    [dir="ltr"] .spt-fill{transform-origin:right;}
    .spt-x{
      position:absolute;top:4px;left:5px;
      font-size:.58rem;color:var(--ink4);opacity:0;
      cursor:pointer;z-index:2;padding:2px 4px;border-radius:4px;
      transition:opacity .15s,background .15s;line-height:1;
    }
    [dir="ltr"] .spt-x{left:auto;right:5px;}
    .spt:hover .spt-x{opacity:.7}
    .spt-x:hover{opacity:1!important;background:var(--bg4);}
  `;
  const styleEl=document.createElement('style');
  styleEl.textContent=css;
  document.head.appendChild(styleEl);

  const wrap=document.createElement('div');
  wrap.id='sp-wrap';
  document.body.appendChild(wrap);

  const rnd=(a,b)=>Math.floor(Math.random()*(b-a+1))+a;
  const pick=a=>a[Math.floor(Math.random()*a.length)];
  const lang=()=>document.documentElement.lang||'ar';
  const isRTL=()=>(document.documentElement.dir||'rtl')==='rtl';

  const PA=['Be Strong Shampoo','المكيف الكثيف','Hair Mist','غسول البشرة بالبابايا','مقشر الوجه Splash','Wiseman Body Splash','لوشن Your Love','Burnmode Tablets','Corepulse Creatine','MaxBulk Gainer','ISO Pro Protein','Package Kit الكاملة'];
  const PE=['Be Strong Shampoo','Conditioner','Hair Mist','Body Wash','Face Scrub','Wiseman Splash','Your Love Lotion','Burnmode Tablets','Creatine','MaxBulk Gainer','ISO Pro Protein','Package Kit'];
  const CA=['القاهرة','الإسكندرية','الجيزة','المنصورة','الرياض','دبي','الكويت','عمّان','بيروت','الدار البيضاء','أسيوط','طنطا','المنيا'];
  const CE=['Cairo','Alexandria','Dubai','Riyadh','Amman','Kuwait','Beirut','Casablanca'];

  const G='#52B788',D='#DEB068',R='#e05c4b',B='#3A90D9';

  const MSGS={
    ar:[
      {a:G,i:'🛒',t:p=>`شخص من ${pick(CA)} طلب للتو`,s:p=>p},
      {a:G,i:'✅',t:p=>`طلب جديد تم تأكيده`,s:p=>`${p} — منذ دقيقة`},
      {a:B,i:'👀',t:p=>`${rnd(5,22)} شخص يتصفح الآن`,s:p=>p},
      {a:R,i:'🔥',t:p=>`طلب مرتفع جداً الآن`,s:p=>`${p} — ${rnd(10,27)} زائر`},
      {a:R,i:'⚠️',t:p=>`كمية محدودة جداً`,s:p=>`باقي ${rnd(2,6)} قطع من ${p}`},
      {a:R,i:'📦',t:p=>`آخر وحدات في المخزون`,s:p=>`${p} — اطلب الآن`},
      {a:D,i:'⏳',t:p=>`عرض ينتهي قريباً`,s:p=>`وفّر على ${p}`},
      {a:D,i:'⭐',t:p=>`تقييم جديد ٥/٥ نجوم`,s:p=>`"نتيجة خيالية!" — ${pick(CA)}`},
      {a:G,i:'💬',t:p=>`عميل سعيد للتو`,s:p=>`"أحسن منتج جربته في حياتي 🌿"`},
      {a:B,i:'🌍',t:p=>`شحن دولي سريع متاح`,s:p=>`${p} يوصل لبلدك`},
      {a:G,i:'🎁',t:p=>`مشتريات متكررة`,s:p=>`عميل من ${pick(CA)} أعاد الطلب مجدداً`},
    ],
    en:[
      {a:G,i:'🛒',t:p=>`Someone in ${pick(CE)} just ordered`,s:p=>p},
      {a:G,i:'✅',t:p=>`New order confirmed`,s:p=>`${p} — moments ago`},
      {a:B,i:'👀',t:p=>`${rnd(5,22)} people viewing now`,s:p=>p},
      {a:R,i:'🔥',t:p=>`High demand right now`,s:p=>`${p} — ${rnd(10,27)} visitors`},
      {a:R,i:'⚠️',t:p=>`Very limited stock`,s:p=>`Only ${rnd(2,6)} left of ${p}`},
      {a:D,i:'⏳',t:p=>`Offer ending soon`,s:p=>`Save on ${p} now`},
      {a:D,i:'⭐',t:p=>`New 5-star review`,s:p=>`"Incredible results!" — ${pick(CE)}`},
      {a:G,i:'💬',t:p=>`Happy customer just now`,s:p=>`"Best product I've ever tried 🌿"`},
      {a:G,i:'🎁',t:p=>`Repeat customer`,s:p=>`A buyer from ${pick(CE)} reordered`},
    ],
    fr:[
      {a:G,i:'🛒',t:p=>`Quelqu'un vient de commander`,s:p=>p},
      {a:B,i:'👀',t:p=>`${rnd(5,22)} personnes consultent`,s:p=>p},
      {a:R,i:'⚠️',t:p=>`Stock très limité`,s:p=>`${rnd(2,6)} unités restantes de ${p}`},
      {a:D,i:'⭐',t:p=>`Nouvel avis 5 étoiles`,s:p=>`"Résultats incroyables !"`},
      {a:D,i:'⏳',t:p=>`Offre se terminant bientôt`,s:p=>`Économisez sur ${p}`},
    ],
  };

  let active=[],paused=false;
  const MAX=2;
  document.addEventListener('visibilitychange',()=>{paused=document.hidden});

  function show(){
    if(paused||active.length>=MAX)return;
    const l=lang();
    const pool=MSGS[l]||MSGS.ar;
    const tpl=pick(pool);
    const pList=l==='en'?PE:PA;
    const p=pick(pList);
    const dur=5200+rnd(0,2400);

    const el=document.createElement('div');
    el.className='spt';
    el.style.setProperty('--spt-accent',tpl.a);
    el.dir=isRTL()?'rtl':'ltr';
    el.innerHTML=
      '<span class="spt-x" title="">✕</span>'+
      '<div class="spt-ico">'+tpl.i+'</div>'+
      '<div class="spt-body">'+
        '<div class="spt-title">'+tpl.t(p)+'</div>'+
        '<div class="spt-sub">'+tpl.s(p)+'</div>'+
      '</div>'+
      '<div class="spt-dot"></div>'+
      '<div class="spt-bar"><div class="spt-fill"></div></div>';

    wrap.appendChild(el);
    active.push(el);

    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      el.classList.add('sp-in');
      const fill=el.querySelector('.spt-fill');
      fill.style.transition='transform '+dur+'ms linear';
      fill.style.transform='scaleX(0)';
    }));

    let tid=setTimeout(()=>bye(el),dur);

    const close=()=>{clearTimeout(tid);bye(el)};
    el.querySelector('.spt-x').addEventListener('click',e=>{e.stopPropagation();close()});
    el.addEventListener('click',close);

    el.addEventListener('mouseenter',()=>{
      clearTimeout(tid);
      el.querySelector('.spt-fill').style.transition='none';
    });
    el.addEventListener('mouseleave',()=>{
      const fill=el.querySelector('.spt-fill');
      fill.style.transition='transform 1800ms linear';
      fill.style.transform='scaleX(0)';
      tid=setTimeout(()=>bye(el),1800);
    });
  }

  function bye(el){
    el.classList.remove('sp-in');
    el.classList.add('sp-out');
    setTimeout(()=>{el.remove();active=active.filter(x=>x!==el)},350);
  }

  /* Schedule */
  setTimeout(()=>{show();loop()},7000+rnd(0,4000));
  function loop(){setTimeout(()=>{show();loop()},9000+rnd(0,11000))}

  /* Keep above FAB */
  function sync(){
    const f=document.getElementById('wa-fab');
    if(f)wrap.style.bottom=(f.getBoundingClientRect().height+18)+'px';
  }
  sync();window.addEventListener('resize',sync,{passive:true});
})();



/* ══════════════════════════════════════════════════
   DISCOUNT BANNER + COUNTDOWN SYSTEM
══════════════════════════════════════════════════ */
(function(){
  var COPY = {
    ar:{badge:'\uD83C\uDFF7\uFE0F خصم خاص',title:'عرض محدود الوقت — وفّر على طلبك الآن',sub:'العرض ينتهي قريباً · اطلب عبر واتساب',lbl:'دقيقة',cta:'اطلب الآن'},
    en:{badge:'\uD83C\uDFF7\uFE0F Special Offer',title:'Limited-time deal — save on your order now',sub:'Offer expires soon · order via WhatsApp',lbl:'min',cta:'Order Now'},
    fr:{badge:'\uD83C\uDFF7\uFE0F Offre Spéciale',title:'Offre limitée — économisez maintenant',sub:"L'offre expire bientôt · commandez via WhatsApp",lbl:'min',cta:'Commander'}
  };
  var CARD_COPY = {
    ar:{ico:'\uD83C\uDFF7\uFE0F',title:'خصم خاص متاح الآن',sub:'هذا العرض محدود الوقت · استغله قبل انتهاء الوقت'},
    en:{ico:'\uD83C\uDFF7\uFE0F',title:'Special discount available now',sub:'Limited-time offer · grab it before it expires'},
    fr:{ico:'\uD83C\uDFF7\uFE0F',title:'Remise spéciale disponible',sub:'Offre à durée limitée · profitez-en avant expiration'}
  };

  var _timer = null;
  var _open = false;

  /* ── Get remaining seconds, persist in sessionStorage ── */
  function getRem(){
    var key = 'pf_disc_end';
    var now = Math.floor(Date.now()/1000);
    var stored = sessionStorage.getItem(key);
    if(stored){
      var rem = parseInt(stored) - now;
      if(rem > 0) return rem;
    }
    var end = now + 600;
    try{ sessionStorage.setItem(key, end); }catch(e){}
    return 600;
  }

  /* ── Format MM:SS ── */
  function fmt(s){ return [Math.floor(s/60),s%60].map(function(x){return String(x).padStart(2,'0')}).join(':'); }

  /* ── Flip digit helper ── */
  function flipDigit(el, val){
    if(!el || el.textContent === val) return;
    el.classList.add('flip');
    setTimeout(function(){ el.textContent = val; el.classList.remove('flip'); }, 160);
  }

  /* ── Update all visible timers ── */
  function updateTimers(){
    var rem = getRem();
    var mm = String(Math.floor(rem/60)).padStart(2,'0');
    var ss = String(rem%60).padStart(2,'0');
    flipDigit(document.getElementById('db-m'), mm);
    flipDigit(document.getElementById('db-s'), ss);
    var te = document.getElementById('db-timer-el');
    if(te) te.classList.toggle('urgent', rem < 120);
    /* inline card */
    var it = document.getElementById('disc-inline-time');
    if(it) it.textContent = mm + ':' + ss;
    return rem;
  }

  /* ── Apply language copy to banner ── */
  function applyLang(){
    var l = document.documentElement.lang || 'ar';
    var c = COPY[l] || COPY.ar;
    var s = function(id, v){ var el=document.getElementById(id); if(el) el.textContent = v; };
    s('db-badge-txt', c.badge);
    s('db-title-txt', c.title);
    s('db-sub-txt', c.sub);
    s('db-timer-lbl-txt', c.lbl);
    s('db-cta-txt', c.cta);
    /* also update inline label */
    var il = document.getElementById('disc-inline-lbl');
    if(il) il.textContent = c.lbl;
  }

  /* ── Start countdown tick ── */
  function startTick(){
    if(_timer) clearInterval(_timer);
    _timer = setInterval(function(){
      var rem = updateTimers();
      if(rem <= 0){
        clearInterval(_timer); _timer = null;
        try{ sessionStorage.removeItem('pf_disc_end'); }catch(e){}
        hideDiscBanner();
      }
    }, 1000);
  }

  /* ── Show banner ── */
  window.showDiscBanner = function(){
    var b = document.getElementById('disc-banner');
    if(!b || _open) return;
    applyLang();
    updateTimers();
    b.classList.add('db-show');
    _open = true;
    startTick();
  };

  /* ── Hide banner ── */
  window.hideDiscBanner = function(){
    var b = document.getElementById('disc-banner');
    if(!b) return;
    b.classList.remove('db-show');
    _open = false;
    if(_timer){ clearInterval(_timer); _timer = null; }
  };

  /* ── discountCardHTML — called from renderProduct template ── */
  window.discountCardHTML = function(){
    var l = document.documentElement.lang || 'ar';
    var c = CARD_COPY[l] || CARD_COPY.ar;
    var lc = COPY[l] || COPY.ar;
    var rem = getRem();
    var t = fmt(rem);
    return '<div class="disc-card rv">'
      + '<span class="disc-card-ico">' + c.ico + '</span>'
      + '<div class="disc-card-body">'
      +   '<div class="disc-card-title">' + c.title + '</div>'
      +   '<div class="disc-card-sub">' + c.sub + '</div>'
      + '</div>'
      + '<div class="disc-card-timer">'
      +   '<div class="disc-card-time" id="disc-inline-time">' + t + '</div>'
      +   '<div class="disc-card-time-lbl" id="disc-inline-lbl">' + lc.lbl + '</div>'
      + '</div>'
      + '</div>';
  };

  /* ── Hook into go() — show banner on product pages, hide elsewhere ── */
  var _origGo = window.go;
  window.go = function(page, id){
    _origGo(page, id);
    setTimeout(function(){
      if(page === 'product'){
        window.showDiscBanner();
        applyLang();
      } else {
        window.hideDiscBanner();
      }
    }, 340);
  };

})();



/* ══════════════════════════════════════════════════════